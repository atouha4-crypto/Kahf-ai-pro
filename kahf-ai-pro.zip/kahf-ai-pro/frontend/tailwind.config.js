/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        arabic: ['Noto Kufi Arabic', 'sans-serif'],
      },
      colors: {
        base: '#1e1e2e',
        mantle: '#181825',
        crust: '#11111b',
        surface0: '#313244',
        surface1: '#45475a',
        surface2: '#585b70',
        overlay0: '#6c7086',
        overlay1: '#7f849c',
        subtext: '#a6adc8',
        text: '#cdd6f4',
        lavender: '#b4befe',
        mauve: '#cba6f7',
        blue: '#89b4fa',
        sapphire: '#74c7ec',
        green: '#a6e3a1',
        red: '#f38ba8',
        peach: '#fab387',
        yellow: '#f9e2af',
      }
    },
  },
  plugins: [],
}