import React, { createContext, useContext, useState, useEffect } from 'react'
import axios from 'axios'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'

const api = axios.create({
  baseURL: API_URL,
  headers: { 'Content-Type': 'application/json' }
})

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  useEffect(() => {
    const token = localStorage.getItem('accessToken')
    if (token) {
      api.defaults.headers.common['Authorization'] = `Bearer ${token}`
      fetchUser()
    } else {
      setLoading(false)
    }
  }, [])

  const fetchUser = async () => {
    try {
      const response = await api.get('/auth/me')
      setUser(response.data.user)
      setIsAuthenticated(true)
    } catch (error) {
      if (error.response?.data?.code === 'TOKEN_EXPIRED') {
        await refreshToken()
      } else {
        logout()
      }
    } finally {
      setLoading(false)
    }
  }

  const refreshToken = async () => {
    try {
      const response = await api.post('/auth/refresh')
      localStorage.setItem('accessToken', response.data.accessToken)
      api.defaults.headers.common['Authorization'] = `Bearer ${response.data.accessToken}`
      await fetchUser()
    } catch (error) {
      logout()
    }
  }

  const login = async (email, password) => {
    const response = await api.post('/auth/login', { email, password })
    const { accessToken, user } = response.data
    localStorage.setItem('accessToken', accessToken)
    api.defaults.headers.common['Authorization'] = `Bearer ${accessToken}`
    setUser(user)
    setIsAuthenticated(true)
    return user
  }

  const register = async (name, email, password) => {
    const response = await api.post('/auth/register', { name, email, password })
    const { accessToken, user } = response.data
    localStorage.setItem('accessToken', accessToken)
    api.defaults.headers.common['Authorization'] = `Bearer ${accessToken}`
    setUser(user)
    setIsAuthenticated(true)
    return user
  }

  const logout = async () => {
    try {
      await api.post('/auth/logout')
    } catch (e) {}
    localStorage.removeItem('accessToken')
    delete api.defaults.headers.common['Authorization']
    setUser(null)
    setIsAuthenticated(false)
  }

  const updateUser = (updatedUser) => {
    setUser(updatedUser)
  }

  return (
    <AuthContext.Provider value={{ 
      user, 
      isAuthenticated, 
      loading, 
      login, 
      register, 
      logout, 
      updateUser,
      api 
    }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) throw new Error('useAuth must be used within AuthProvider')
  return context
}

export { api }
