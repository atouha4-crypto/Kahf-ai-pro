import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import { motion } from 'framer-motion'
import { 
  Shield, Users, Type, DollarSign, Activity, 
  ArrowLeft, Loader2, Trash2, Search, BarChart3,
  TrendingUp, TrendingDown, Mail, MessageSquare,
  ChevronLeft, ChevronRight, X
} from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts'

const COLORS = ['#b4befe', '#cba6f7', '#89b4fa', '#a6e3a1', '#fab387']

export default function AdminPage() {
  const { user, isAuthenticated, loading: authLoading, api } = useAuth()
  const navigate = useNavigate()
  const [stats, setStats] = useState(null)
  const [users, setUsers] = useState([])
  const [translations, setTranslations] = useState([])
  const [contacts, setContacts] = useState([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('overview')
  const [userPage, setUserPage] = useState(1)
  const [userTotalPages, setUserTotalPages] = useState(1)
  const [searchUser, setSearchUser] = useState('')
  const [deleteLoading, setDeleteLoading] = useState(null)

  useEffect(() => {
    if (!authLoading) {
      if (!isAuthenticated) {
        navigate('/?auth=login')
      } else if (user?.role !== 'admin') {
        navigate('/dashboard')
      }
    }
  }, [authLoading, isAuthenticated, user, navigate])

  useEffect(() => {
    if (isAuthenticated && user?.role === 'admin') {
      fetchAdminData()
    }
  }, [isAuthenticated, user, activeTab, userPage])

  const fetchAdminData = async () => {
    setLoading(true)
    try {
      const [statsRes, usersRes, transRes, contactsRes] = await Promise.all([
        api.get('/admin/stats'),
        api.get(`/admin/users?page=${userPage}&limit=20`),
        api.get('/admin/translations'),
        api.get('/admin/contacts'),
      ])

      setStats(statsRes.data)
      setUsers(usersRes.data.users)
      setUserTotalPages(usersRes.data.totalPages)
      setTranslations(transRes.data.translations)
      setContacts(contactsRes.data.contacts)
    } catch (err) {
      console.error('Admin error:', err)
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteUser = async (userId) => {
    if (!confirm('هل أنت متأكد من حذف هذا المستخدم؟ لا يمكن التراجع.')) return

    setDeleteLoading(userId)
    try {
      await api.delete(`/admin/users/${userId}`)
      setUsers(users.filter(u => u._id !== userId))
    } catch (err) {
      alert('فشل حذف المستخدم')
    } finally {
      setDeleteLoading(null)
    }
  }

  const filteredUsers = users.filter(u => 
    u.name.toLowerCase().includes(searchUser.toLowerCase()) ||
    u.email.toLowerCase().includes(searchUser.toLowerCase())
  )

  // Prepare chart data
  const dailyChartData = stats?.dailyStats?.map(d => ({
    date: d._id.slice(5),
    translations: d.count
  }))?.reverse() || []

  const planDistribution = [
    { name: 'مجاني', value: users.filter(u => u.plan === 'free').length },
    { name: 'Pro', value: users.filter(u => u.plan === 'pro').length },
    { name: 'Business', value: users.filter(u => u.plan === 'business').length },
  ].filter(p => p.value > 0)

  if (authLoading || loading) {
    return (
      <div className="pt-24 flex items-center justify-center min-h-screen">
        <Loader2 size={40} className="text-lavender animate-spin" />
      </div>
    )
  }

  if (!isAuthenticated || user?.role !== 'admin') return null

  return (
    <div className="pt-24 pb-20 px-4 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-4 mb-2">
            <div className="p-2 bg-mauve/20 rounded-xl">
              <Shield size={24} className="text-mauve" />
            </div>
            <div>
              <h1 className="text-3xl font-black text-white">لوحة تحكم المدير</h1>
              <p className="text-subtext text-sm">كهف AI Pro - Admin Dashboard</p>
            </div>
          </div>
        </motion.div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'إجمالي المستخدمين', value: stats?.totalUsers || 0, icon: Users, color: 'lavender' },
            { label: 'إجمالي الترجمات', value: stats?.totalTranslations || 0, icon: Type, color: 'blue' },
            { label: 'الإيرادات ($)', value: `$${(stats?.totalRevenue || 0).toFixed(2)}`, icon: DollarSign, color: 'green' },
            { label: 'نشطون هذا الأسبوع', value: stats?.activeUsers || 0, icon: Activity, color: 'peach' },
          ].map((stat, i) => {
            const Icon = stat.icon
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="card"
              >
                <div className="flex items-center gap-3 mb-3">
                  <div className={`p-2 bg-${stat.color}/10 rounded-lg`}>
                    <Icon size={18} className={`text-${stat.color}`} />
                  </div>
                  <span className="text-subtext text-xs">{stat.label}</span>
                </div>
                <div className="text-2xl font-black text-white">{stat.value}</div>
              </motion.div>
            )
          })}
        </div>

        {/* Charts */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="card"
          >
            <h3 className="text-white font-bold flex items-center gap-2 mb-4">
              <BarChart3 size={18} className="text-lavender" />
              إحصائيات الترجمة (آخر 7 أيام)
            </h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={dailyChartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#313244" />
                  <XAxis dataKey="date" stroke="#6c7086" fontSize={12} />
                  <YAxis stroke="#6c7086" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ background: '#181825', border: '1px solid #313244', borderRadius: '8px' }}
                    labelStyle={{ color: '#cdd6f4' }}
                  />
                  <Bar dataKey="translations" fill="#b4befe" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="card"
          >
            <h3 className="text-white font-bold flex items-center gap-2 mb-4">
              <TrendingUp size={18} className="text-mauve" />
              توزيع الخطط
            </h3>
            <div className="h-64 flex items-center justify-center">
              {planDistribution.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={planDistribution}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {planDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ background: '#181825', border: '1px solid #313244', borderRadius: '8px' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <p className="text-subtext">لا توجد بيانات كافية</p>
              )}
            </div>
            <div className="flex justify-center gap-4 mt-2">
              {planDistribution.map((p, i) => (
                <div key={p.name} className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ background: COLORS[i] }} />
                  <span className="text-subtext text-xs">{p.name}: {p.value}</span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 overflow-x-auto">
          {[
            { id: 'users', label: 'المستخدمين', icon: Users },
            { id: 'translations', label: 'الترجمات', icon: Type },
            { id: 'contacts', label: 'التواصل', icon: MessageSquare },
          ].map(tab => {
            const Icon = tab.icon
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-bold transition-all whitespace-nowrap ${
                  activeTab === tab.id 
                    ? 'bg-lavender text-base' 
                    : 'bg-surface0 text-subtext hover:text-text'
                }`}
              >
                <Icon size={16} />
                {tab.label}
              </button>
            )
          })}
        </div>

        {/* Users Tab */}
        {activeTab === 'users' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="card"
          >
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-white font-bold">المستخدمون المسجلون</h3>
              <div className="relative">
                <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-overlay1" />
                <input
                  type="text"
                  value={searchUser}
                  onChange={e => setSearchUser(e.target.value)}
                  className="input-field pr-10 py-2 text-sm w-64"
                  placeholder="بحث..."
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-surface0">
                    <th className="text-right py-3 px-4 text-subtext text-xs font-bold">#</th>
                    <th className="text-right py-3 px-4 text-subtext text-xs font-bold">الاسم</th>
                    <th className="text-right py-3 px-4 text-subtext text-xs font-bold">البريد</th>
                    <th className="text-right py-3 px-4 text-subtext text-xs font-bold">الخطة</th>
                    <th className="text-right py-3 px-4 text-subtext text-xs font-bold">الدور</th>
                    <th className="text-right py-3 px-4 text-subtext text-xs font-bold">التسجيل</th>
                    <th className="text-right py-3 px-4 text-subtext text-xs font-bold">إجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredUsers.map((u, i) => (
                    <tr key={u._id} className="border-b border-surface0/50 hover:bg-white/5 transition-colors">
                      <td className="py-3 px-4 text-overlay1 text-sm">{(userPage - 1) * 20 + i + 1}</td>
                      <td className="py-3 px-4 text-text text-sm font-medium">{u.name}</td>
                      <td className="py-3 px-4 text-blue text-sm" dir="ltr">{u.email}</td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                          u.plan === 'business' ? 'bg-mauve/20 text-mauve' :
                          u.plan === 'pro' ? 'bg-lavender/20 text-lavender' :
                          'bg-surface0 text-subtext'
                        }`}>
                          {u.plan}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`text-xs font-bold ${u.role === 'admin' ? 'text-mauve' : 'text-blue'}`}>
                          {u.role === 'admin' ? '🛡️ مدير' : '👤 مستخدم'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-overlay1 text-sm">
                        {new Date(u.createdAt).toLocaleDateString('ar-SA')}
                      </td>
                      <td className="py-3 px-4">
                        {u.role !== 'admin' && (
                          <button
                            onClick={() => handleDeleteUser(u._id)}
                            disabled={deleteLoading === u._id}
                            className="p-2 hover:bg-red/10 rounded-lg text-subtext hover:text-red transition-colors disabled:opacity-50"
                            title="حذف"
                          >
                            {deleteLoading === u._id ? (
                              <Loader2 size={16} className="animate-spin" />
                            ) : (
                              <Trash2 size={16} />
                            )}
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            {userTotalPages > 1 && (
              <div className="flex items-center justify-center gap-3 mt-6">
                <button
                  onClick={() => setUserPage(p => Math.max(1, p - 1))}
                  disabled={userPage === 1}
                  className="p-2 bg-surface0 rounded-lg hover:bg-surface1 transition-colors disabled:opacity-50"
                >
                  <ChevronRight size={18} />
                </button>
                <span className="text-subtext text-sm">صفحة {userPage} من {userTotalPages}</span>
                <button
                  onClick={() => setUserPage(p => Math.min(userTotalPages, p + 1))}
                  disabled={userPage === userTotalPages}
                  className="p-2 bg-surface0 rounded-lg hover:bg-surface1 transition-colors disabled:opacity-50"
                >
                  <ChevronLeft size={18} />
                </button>
              </div>
            )}
          </motion.div>
        )}

        {/* Translations Tab */}
        {activeTab === 'translations' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="card"
          >
            <h3 className="text-white font-bold mb-6">سجل الترجمات الأخيرة</h3>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-surface0">
                    <th className="text-right py-3 px-4 text-subtext text-xs font-bold">المستخدم</th>
                    <th className="text-right py-3 px-4 text-subtext text-xs font-bold">من</th>
                    <th className="text-right py-3 px-4 text-subtext text-xs font-bold">إلى</th>
                    <th className="text-right py-3 px-4 text-subtext text-xs font-bold">النص</th>
                    <th className="text-right py-3 px-4 text-subtext text-xs font-bold">الوقت</th>
                  </tr>
                </thead>
                <tbody>
                  {translations.map((t, i) => (
                    <tr key={i} className="border-b border-surface0/50 hover:bg-white/5 transition-colors">
                      <td className="py-3 px-4 text-text text-sm">{t.userEmail || 'زائر'}</td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-1 bg-surface0 rounded text-xs">{t.sourceLang}</span>
                      </td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-1 bg-surface0 rounded text-xs">{t.targetLang}</span>
                      </td>
                      <td className="py-3 px-4 text-text text-sm max-w-xs truncate">{t.text || t.sourceText}</td>
                      <td className="py-3 px-4 text-overlay1 text-xs">
                        {new Date(t.createdAt || t.time).toLocaleString('ar-SA')}
                      </td>
                    </tr>
                  ))}
                  {translations.length === 0 && (
                    <tr>
                      <td colSpan="5" className="py-8 text-center text-subtext">
                        لا توجد ترجمات بعد
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </motion.div>
        )}

        {/* Contacts Tab */}
        {activeTab === 'contacts' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="card"
          >
            <h3 className="text-white font-bold mb-6">رسائل التواصل</h3>
            <div className="space-y-4">
              {contacts.map((c, i) => (
                <div key={i} className="p-4 bg-crust rounded-xl">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-lavender to-mauve rounded-full flex items-center justify-center text-base font-bold">
                        {c.name.charAt(0)}
                      </div>
                      <div>
                        <h4 className="text-white font-bold text-sm">{c.name}</h4>
                        <p className="text-subtext text-xs">{c.email}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                        c.status === 'new' ? 'bg-peach/20 text-peach' :
                        c.status === 'replied' ? 'bg-green/20 text-green' :
                        'bg-surface0 text-subtext'
                      }`}>
                        {c.status}
                      </span>
                      <span className="text-overlay1 text-xs">
                        {new Date(c.createdAt).toLocaleDateString('ar-SA')}
                      </span>
                    </div>
                  </div>
                  <p className="text-text text-sm leading-relaxed">{c.message}</p>
                  {c.phone && (
                    <p className="text-subtext text-xs mt-2">📱 {c.phone}</p>
                  )}
                </div>
              ))}
              {contacts.length === 0 && (
                <div className="text-center py-8 text-subtext">
                  <Mail size={32} className="mx-auto mb-3 opacity-50" />
                  <p>لا توجد رسائل تواصل بعد</p>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </div>
    </div>
  )
}
