# 🚀 دليل النشر - كهف AI Pro

## الخيار 1: Render.com (مجاني)

### Backend
1. أنشئ حساب على [render.com](https://render.com)
2. أنشئ Web Service جديد
3. اربط repository GitHub
4. اضبط:
   - Build Command: `npm install`
   - Start Command: `node server.js`
5. أضف Environment Variables من `.env`
6. أنشئ MongoDB Atlas cluster مجاني
7. انسخ URI إلى `MONGODB_URI`

### Frontend
1. أنشئ Static Site جديد
2. اربط نفس repository
3. Build Command: `npm install && npm run build`
4. Publish Directory: `dist`
5. أضف Environment Variables

---

## الخيار 2: Railway (سهل)

```bash
# Install Railway CLI
npm install -g @railway/cli

# Login
railway login

# Deploy backend
cd backend
railway init
railway up

# Deploy frontend
cd ../frontend
railway init
railway up
```

---

## الخيار 3: VPS (التحكم الكامل)

### Ubuntu 22.04

```bash
# Update
sudo apt update && sudo apt upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install MongoDB
wget -qO - https://www.mongodb.org/static/pgp/server-7.0.asc | sudo apt-key add -
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu jammy/mongodb-org/7.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-7.0.list
sudo apt update
sudo apt install -y mongodb-org
sudo systemctl start mongod
sudo systemctl enable mongod

# Install PM2
sudo npm install -g pm2

# Clone project
git clone https://github.com/yourusername/kahf-ai-pro.git
cd kahf-ai-pro

# Setup backend
cd backend
npm install
cp .env.example .env
# Edit .env
pm2 start server.js --name "kahf-api"

# Setup frontend
cd ../frontend
npm install
npm run build
# Serve with nginx or pm2

# Save PM2 config
pm2 save
pm2 startup
```

### Nginx Config

```nginx
server {
    listen 80;
    server_name kahf.ai www.kahf.ai;

    location / {
        root /var/www/kahf-ai-pro/frontend/dist;
        try_files $uri $uri/ /index.html;
    }

    location /api {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

---

## 🔒 SSL Certificate (Let's Encrypt)

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d kahf.ai -d www.kahf.ai
```

---

## 📱 إعداد واتساب بزنس

1. أنشئ حساب على [business.whatsapp.com](https://business.whatsapp.com)
2. احصل على API Key
3. أضف `WHATSAPP_API_KEY` و `WHATSAPP_PHONE_NUMBER` إلى `.env`
4. ربط Webhook للردود التلقائية

---

## 📧 إعداد البريد (Gmail)

1. فعّل Two-Factor Authentication
2. أنشئ App Password
3. أضف إلى `.env`:
   - `EMAIL_USER=your-email@gmail.com`
   - `EMAIL_PASS=your-app-password`

---

## 💳 إعداد Stripe

1. أنشئ حساب على [stripe.com](https://stripe.com)
2. احصل على API Keys من Dashboard
3. أضف Webhook endpoint: `https://your-domain.com/api/webhook`
4. اختر events: `checkout.session.completed`, `invoice.payment_failed`
5. انسخ Webhook Secret إلى `.env`

---

## 🔄 CI/CD (GitHub Actions)

```yaml
# .github/workflows/deploy.yml
name: Deploy

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-version: '20'

      - name: Deploy Backend
        run: |
          cd backend
          npm install
          # Add your deploy commands

      - name: Deploy Frontend
        run: |
          cd frontend
          npm install
          npm run build
          # Add your deploy commands
```

---

## 📊 Monitoring

```bash
# PM2 monitoring
pm2 monit

# Logs
pm2 logs kahf-api

# Restart
pm2 restart kahf-api
```

---

## 🆘 Troubleshooting

| المشكلة | الحل |
|---------|------|
| MongoDB connection error | تأكد من تشغيل `mongod` |
| CORS error | تأكد من `CLIENT_URL` في `.env` |
| Stripe webhook fails | تأكد من `STRIPE_WEBHOOK_SECRET` |
| Build fails | `rm -rf node_modules && npm install` |

---

**للمساعدة:** [admin@kahf.ai](mailto:admin@kahf.ai) | [واتساب](https://wa.me/966XXXXXXXXX)
