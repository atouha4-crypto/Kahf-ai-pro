import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { useAuth } from '../contexts/AuthContext'
import { Mail, Phone, MessageCircle, Send, CheckCircle, AlertCircle, MapPin } from 'lucide-react'

export default function ContactPage() {
  const { api } = useAuth()
  const [form, setForm] = useState({ name: '', email: '', phone: '', message: '', source: 'website' })
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      await api.post('/contact', form)
      setSuccess(true)
      setForm({ name: '', email: '', phone: '', message: '', source: 'website' })
    } catch (err) {
      setError(err.response?.data?.message || 'فشل إرسال الرسالة. حاول مرة أخرى.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="pt-24 pb-20 px-4 min-h-screen">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl font-black text-white mb-4"
          >
            تواصل معنا
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-subtext max-w-lg mx-auto"
          >
            نحن هنا لمساعدتك. تواصل معنا عبر البريد الإلكتروني أو الواتساب
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div className="card mb-6">
              <h3 className="text-white font-bold text-lg mb-6">معلومات التواصل</h3>

              <div className="space-y-5">
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-lavender/10 rounded-xl shrink-0">
                    <Mail size={20} className="text-lavender" />
                  </div>
                  <div>
                    <h4 className="text-white font-bold text-sm mb-1">البريد الإلكتروني</h4>
                    <a href="mailto:admin@kahf.ai" className="text-lavender hover:underline text-sm no-underline">
                      admin@kahf.ai
                    </a>
                    <p className="text-overlay1 text-xs mt-1">الرد خلال 24 ساعة</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="p-3 bg-green/10 rounded-xl shrink-0">
                    <Phone size={20} className="text-green" />
                  </div>
                  <div>
                    <h4 className="text-white font-bold text-sm mb-1">واتساب</h4>
                    <a href="https://wa.me/966XXXXXXXXX" target="_blank" rel="noopener noreferrer" 
                       className="text-green hover:underline text-sm no-underline">
                      +966 XX XXX XXXX
                    </a>
                    <p className="text-overlay1 text-xs mt-1">دعم فوري للمشتركين Business</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="p-3 bg-mauve/10 rounded-xl shrink-0">
                    <MessageCircle size={20} className="text-mauve" />
                  </div>
                  <div>
                    <h4 className="text-white font-bold text-sm mb-1">تيليجرام</h4>
                    <a href="https://t.me/kahf_ai_support" target="_blank" rel="noopener noreferrer"
                       className="text-mauve hover:underline text-sm no-underline">
                      @kahf_ai_support
                    </a>
                    <p className="text-overlay1 text-xs mt-1">تحديثات وإعلانات</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="p-3 bg-blue/10 rounded-xl shrink-0">
                    <MapPin size={20} className="text-blue" />
                  </div>
                  <div>
                    <h4 className="text-white font-bold text-sm mb-1">الموقع</h4>
                    <p className="text-subtext text-sm">الرياض، المملكة العربية السعودية</p>
                    <p className="text-overlay1 text-xs mt-1">متاحون للاجتماعات في المنطقة</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="card">
              <h3 className="text-white font-bold text-lg mb-4">روابط سريعة</h3>
              <div className="grid grid-cols-2 gap-3">
                <a href="/pricing" className="p-3 bg-surface0 rounded-xl text-center hover:bg-surface1 transition-colors no-underline">
                  <span className="text-lavender text-sm font-bold">الأسعار</span>
                </a>
                <a href="/dashboard" className="p-3 bg-surface0 rounded-xl text-center hover:bg-surface1 transition-colors no-underline">
                  <span className="text-green text-sm font-bold">لوحة التحكم</span>
                </a>
              </div>
            </div>
          </motion.div>

          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <div className="card">
              <h3 className="text-white font-bold text-lg mb-6">أرسل رسالتك</h3>

              {success ? (
                <div className="text-center py-12">
                  <CheckCircle size={64} className="text-green mx-auto mb-4" />
                  <h4 className="text-white font-bold text-xl mb-2">تم الإرسال بنجاح!</h4>
                  <p className="text-subtext">سنرد عليك في أقرب وقت ممكن</p>
                  <button 
                    onClick={() => setSuccess(false)}
                    className="btn-primary mt-6"
                  >
                    رسالة جديدة
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  {error && (
                    <div className="flex items-center gap-2 bg-red/10 border border-red/30 rounded-lg px-4 py-3 text-red text-sm">
                      <AlertCircle size={16} />
                      {error}
                    </div>
                  )}

                  <div>
                    <label className="block text-subtext text-xs mb-2">الاسم الكامل *</label>
                    <input
                      type="text"
                      value={form.name}
                      onChange={e => setForm({...form, name: e.target.value})}
                      className="input-field"
                      placeholder="أدخل اسمك"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-subtext text-xs mb-2">البريد الإلكتروني *</label>
                    <input
                      type="email"
                      value={form.email}
                      onChange={e => setForm({...form, email: e.target.value})}
                      className="input-field"
                      placeholder="example@email.com"
                      dir="ltr"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-subtext text-xs mb-2">رقم الهاتف (اختياري)</label>
                    <input
                      type="tel"
                      value={form.phone}
                      onChange={e => setForm({...form, phone: e.target.value})}
                      className="input-field"
                      placeholder="+966 XX XXX XXXX"
                      dir="ltr"
                    />
                  </div>

                  <div>
                    <label className="block text-subtext text-xs mb-2">الرسالة *</label>
                    <textarea
                      value={form.message}
                      onChange={e => setForm({...form, message: e.target.value})}
                      className="input-field h-32 resize-none"
                      placeholder="اكتب رسالتك هنا..."
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-3 bg-lavender text-base font-bold rounded-xl hover:scale-[1.02] hover:shadow-lg hover:shadow-lavender/30 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {loading ? (
                      <span className="inline-block w-5 h-5 border-2 border-base/30 border-t-base rounded-full animate-spin" />
                    ) : (
                      <><Send size={18} /> إرسال الرسالة</>
                    )}
                  </button>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  )
}
