import React, { useState } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { X, AlertCircle } from 'lucide-react'

export default function AuthModal({ isOpen, onClose, defaultTab = 'login' }) {
  const [tab, setTab] = useState(defaultTab)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const { login, register } = useAuth()

  const [loginData, setLoginData] = useState({ email: '', password: '' })
  const [registerData, setRegisterData] = useState({ name: '', email: '', password: '' })

  if (!isOpen) return null

  const handleLogin = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      await login(loginData.email, loginData.password)
      onClose()
    } catch (err) {
      setError(err.response?.data?.message || 'فشل تسجيل الدخول')
    } finally {
      setLoading(false)
    }
  }

  const handleRegister = async (e) => {
    e.preventDefault()
    setError('')
    if (registerData.password.length < 6) {
      setError('كلمة المرور يجب أن تكون 6 أحرف على الأقل')
      return
    }
    setLoading(true)
    try {
      await register(registerData.name, registerData.email, registerData.password)
      onClose()
    } catch (err) {
      setError(err.response?.data?.message || 'فشل إنشاء الحساب')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-crust/85 backdrop-blur-lg" />

      <div 
        className="relative bg-mantle border border-surface0 rounded-2xl p-8 w-full max-w-md shadow-2xl"
        onClick={e => e.stopPropagation()}
      >
        <button 
          onClick={onClose}
          className="absolute top-4 left-4 text-overlay1 hover:text-red transition-colors"
        >
          <X size={20} />
        </button>

        <h2 className="text-2xl font-extrabold text-white text-center mb-1">
          مرحباً بك في كهف AI
        </h2>
        <p className="text-subtext text-sm text-center mb-6">
          {tab === 'login' ? 'سجّل دخولك للوصول إلى كامل المميزات' : 'أنشئ حسابك وابدأ الترجمة الذكية'}
        </p>

        {/* Tabs */}
        <div className="flex bg-crust rounded-xl p-1 mb-6 gap-1">
          <button
            onClick={() => { setTab('login'); setError('') }}
            className={`flex-1 py-2.5 rounded-lg text-sm font-bold transition-all ${
              tab === 'login' ? 'bg-surface0 text-lavender' : 'text-subtext hover:text-text'
            }`}
          >
            تسجيل الدخول
          </button>
          <button
            onClick={() => { setTab('register'); setError('') }}
            className={`flex-1 py-2.5 rounded-lg text-sm font-bold transition-all ${
              tab === 'register' ? 'bg-surface0 text-lavender' : 'text-subtext hover:text-text'
            }`}
          >
            حساب جديد
          </button>
        </div>

        {/* Error */}
        {error && (
          <div className="flex items-center gap-2 bg-red/10 border border-red/30 rounded-lg px-4 py-3 mb-4 text-red text-sm">
            <AlertCircle size={16} />
            {error}
          </div>
        )}

        {/* Login Form */}
        {tab === 'login' && (
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-subtext text-xs mb-2">البريد الإلكتروني</label>
              <input
                type="email"
                value={loginData.email}
                onChange={e => setLoginData({...loginData, email: e.target.value})}
                className="input-field"
                placeholder="example@email.com"
                dir="ltr"
                required
              />
            </div>
            <div>
              <label className="block text-subtext text-xs mb-2">كلمة المرور</label>
              <input
                type="password"
                value={loginData.password}
                onChange={e => setLoginData({...loginData, password: e.target.value})}
                className="input-field"
                placeholder="••••••••"
                dir="ltr"
                required
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-lavender text-base font-bold rounded-xl hover:scale-[1.02] hover:shadow-lg hover:shadow-lavender/30 transition-all disabled:opacity-50"
            >
              {loading ? (
                <span className="inline-block w-5 h-5 border-2 border-base/30 border-t-base rounded-full animate-spin" />
              ) : 'دخول'}
            </button>
          </form>
        )}

        {/* Register Form */}
        {tab === 'register' && (
          <form onSubmit={handleRegister} className="space-y-4">
            <div>
              <label className="block text-subtext text-xs mb-2">الاسم الكامل</label>
              <input
                type="text"
                value={registerData.name}
                onChange={e => setRegisterData({...registerData, name: e.target.value})}
                className="input-field"
                placeholder="أدخل اسمك"
                required
              />
            </div>
            <div>
              <label className="block text-subtext text-xs mb-2">البريد الإلكتروني</label>
              <input
                type="email"
                value={registerData.email}
                onChange={e => setRegisterData({...registerData, email: e.target.value})}
                className="input-field"
                placeholder="example@email.com"
                dir="ltr"
                required
              />
            </div>
            <div>
              <label className="block text-subtext text-xs mb-2">كلمة المرور (6 أحرف على الأقل)</label>
              <input
                type="password"
                value={registerData.password}
                onChange={e => setRegisterData({...registerData, password: e.target.value})}
                className="input-field"
                placeholder="••••••••"
                dir="ltr"
                required
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-lavender text-base font-bold rounded-xl hover:scale-[1.02] hover:shadow-lg hover:shadow-lavender/30 transition-all disabled:opacity-50"
            >
              {loading ? (
                <span className="inline-block w-5 h-5 border-2 border-base/30 border-t-base rounded-full animate-spin" />
              ) : 'إنشاء حساب'}
            </button>
          </form>
        )}
      </div>
    </div>
  )
}
