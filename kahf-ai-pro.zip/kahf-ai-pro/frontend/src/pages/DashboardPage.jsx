import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import { motion } from 'framer-motion'
import { 
  User, Mail, Calendar, Type, Crown, CreditCard, 
  ArrowLeft, Loader2, CheckCircle, AlertTriangle,
  BarChart3, History, Settings, LogOut
} from 'lucide-react'

export default function DashboardPage() {
  const { user, isAuthenticated, loading: authLoading, logout, api } = useAuth()
  const navigate = useNavigate()
  const [stats, setStats] = useState(null)
  const [recentTranslations, setRecentTranslations] = useState([])
  const [loading, setLoading] = useState(true)
  const [cancelLoading, setCancelLoading] = useState(false)

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      navigate('/?auth=login')
    }
  }, [authLoading, isAuthenticated, navigate])

  useEffect(() => {
    if (isAuthenticated) {
      fetchDashboardData()
    }
  }, [isAuthenticated])

  const fetchDashboardData = async () => {
    try {
      const [historyRes] = await Promise.all([
        api.get('/translate/history?limit=5'),
      ])
      setRecentTranslations(historyRes.data.translations)

      // Calculate stats from user data
      setStats({
        totalTranslations: user?.translationsCount || 0,
        charactersUsed: user?.charactersUsed || 0,
        charactersLimit: user?.translationsLimit || 500,
        plan: user?.plan || 'free',
      })
    } catch (err) {
      console.error('Dashboard error:', err)
    } finally {
      setLoading(false)
    }
  }

  const handleCancelSubscription = async () => {
    if (!confirm('هل أنت متأكد من إلغاء الاشتراك؟ ستبقى الخطة الحالية حتى نهاية الفترة.')) return

    setCancelLoading(true)
    try {
      await api.post('/cancel-subscription')
      alert('تم إلغاء الاشتراك بنجاح')
      window.location.reload()
    } catch (err) {
      alert('فشل إلغاء الاشتراك')
    } finally {
      setCancelLoading(false)
    }
  }

  const usagePercentage = stats ? Math.min((stats.charactersUsed / stats.charactersLimit) * 100, 100) : 0

  if (authLoading || loading) {
    return (
      <div className="pt-24 flex items-center justify-center min-h-screen">
        <Loader2 size={40} className="text-lavender animate-spin" />
      </div>
    )
  }

  if (!isAuthenticated) return null

  return (
    <div className="pt-24 pb-20 px-4 min-h-screen">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-black text-white mb-2">لوحة التحكم</h1>
          <p className="text-subtext">إدارة حسابك واستخدامك</p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6">
          {/* Profile Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="card md:col-span-1"
          >
            <div className="text-center mb-6">
              <div className="w-20 h-20 bg-gradient-to-br from-lavender to-mauve rounded-full flex items-center justify-center text-2xl font-black text-base mx-auto mb-4">
                {user?.name?.charAt(0)}
              </div>
              <h3 className="text-white font-bold text-lg">{user?.name}</h3>
              <p className="text-subtext text-sm">{user?.email}</p>
              <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold mt-3 ${
                user?.plan === 'business' ? 'bg-mauve/20 text-mauve' :
                user?.plan === 'pro' ? 'bg-lavender/20 text-lavender' :
                'bg-surface0 text-subtext'
              }`}>
                <Crown size={12} />
                {user?.plan === 'business' ? 'Business' : user?.plan === 'pro' ? 'Pro' : 'مجاني'}
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-3 p-3 bg-crust rounded-xl">
                <Calendar size={16} className="text-overlay1" />
                <div>
                  <p className="text-overlay1 text-xs">تاريخ التسجيل</p>
                  <p className="text-text text-sm">{new Date(user?.createdAt).toLocaleDateString('ar-SA')}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-crust rounded-xl">
                <Mail size={16} className="text-overlay1" />
                <div>
                  <p className="text-overlay1 text-xs">البريد</p>
                  <p className="text-text text-sm">{user?.email}</p>
                </div>
              </div>
            </div>

            <div className="mt-6 space-y-2">
              <a href="/history" className="flex items-center gap-2 p-3 bg-surface0 rounded-xl hover:bg-surface1 transition-colors no-underline">
                <History size={16} className="text-lavender" />
                <span className="text-text text-sm">سجل الترجمات</span>
                <ArrowLeft size={14} className="mr-auto text-overlay1" />
              </a>
              <a href="/pricing" className="flex items-center gap-2 p-3 bg-surface0 rounded-xl hover:bg-surface1 transition-colors no-underline">
                <CreditCard size={16} className="text-green" />
                <span className="text-text text-sm">الاشتراك</span>
                <ArrowLeft size={14} className="mr-auto text-overlay1" />
              </a>
              <button 
                onClick={() => logout()}
                className="flex items-center gap-2 p-3 bg-surface0 rounded-xl hover:bg-red/10 hover:text-red transition-colors w-full text-right"
              >
                <LogOut size={16} />
                <span className="text-text text-sm">تسجيل الخروج</span>
              </button>
            </div>
          </motion.div>

          {/* Stats & Usage */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="md:col-span-2 space-y-6"
          >
            {/* Usage Stats */}
            <div className="card">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-white font-bold flex items-center gap-2">
                  <BarChart3 size={18} className="text-lavender" />
                  استخدامك
                </h3>
                <span className={`text-xs font-bold px-2 py-1 rounded-full ${
                  usagePercentage > 90 ? 'bg-red/20 text-red' :
                  usagePercentage > 70 ? 'bg-peach/20 text-peach' :
                  'bg-green/20 text-green'
                }`}>
                  {Math.round(usagePercentage)}%
                </span>
              </div>

              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-subtext">الأحرف المستخدمة</span>
                    <span className="text-white font-bold">{stats?.charactersUsed?.toLocaleString()} / {stats?.charactersLimit?.toLocaleString()}</span>
                  </div>
                  <div className="h-3 bg-crust rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all duration-500 ${
                        usagePercentage > 90 ? 'bg-red' :
                        usagePercentage > 70 ? 'bg-peach' :
                        'bg-lavender'
                      }`}
                      style={{ width: `${usagePercentage}%` }}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-crust rounded-xl text-center">
                    <div className="text-2xl font-black text-lavender">{stats?.totalTranslations?.toLocaleString()}</div>
                    <div className="text-subtext text-xs">إجمالي الترجمات</div>
                  </div>
                  <div className="p-4 bg-crust rounded-xl text-center">
                    <div className="text-2xl font-black text-green">
                      {stats?.charactersLimit === 500 ? '500' : '∞'}
                    </div>
                    <div className="text-subtext text-xs">الحد اليومي</div>
                  </div>
                </div>
              </div>

              {usagePercentage > 90 && (
                <div className="mt-4 flex items-center gap-2 bg-peach/10 border border-peach/30 rounded-lg px-4 py-3 text-peach text-sm">
                  <AlertTriangle size={16} />
                  اقتربت من الحد اليومي. <a href="/pricing" className="underline hover:text-lavender">ارقِ إلى Pro</a>
                </div>
              )}
            </div>

            {/* Subscription Management */}
            {(user?.plan === 'pro' || user?.plan === 'business') && (
              <div className="card">
                <h3 className="text-white font-bold flex items-center gap-2 mb-4">
                  <CreditCard size={18} className="text-green" />
                  إدارة الاشتراك
                </h3>
                <div className="flex items-center justify-between p-4 bg-crust rounded-xl">
                  <div>
                    <p className="text-white font-bold">{user?.plan === 'pro' ? 'Pro Plan' : 'Business Plan'}</p>
                    <p className="text-subtext text-sm">${user?.plan === 'pro' ? '9' : '29'}/شهر</p>
                  </div>
                  <div className="flex items-center gap-2 text-green">
                    <CheckCircle size={16} />
                    <span className="text-sm font-bold">نشط</span>
                  </div>
                </div>
                <button
                  onClick={handleCancelSubscription}
                  disabled={cancelLoading}
                  className="mt-4 w-full py-2.5 border border-red/30 text-red rounded-xl hover:bg-red/10 transition-all text-sm font-bold disabled:opacity-50"
                >
                  {cancelLoading ? 'جاري الإلغاء...' : 'إلغاء الاشتراك'}
                </button>
              </div>
            )}

            {/* Recent Translations */}
            <div className="card">
              <h3 className="text-white font-bold flex items-center gap-2 mb-4">
                <History size={18} className="text-blue" />
                آخر الترجمات
              </h3>

              {recentTranslations.length === 0 ? (
                <div className="text-center py-8 text-subtext">
                  <Type size={32} className="mx-auto mb-3 opacity-50" />
                  <p>لم تقم بأي ترجمات بعد</p>
                  <a href="/" className="text-lavender hover:underline text-sm mt-2 inline-block no-underline">
                    ابدأ الترجمة الآن
                  </a>
                </div>
              ) : (
                <div className="space-y-3">
                  {recentTranslations.map((t, i) => (
                    <div key={i} className="p-3 bg-crust rounded-xl">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-xs bg-surface0 px-2 py-0.5 rounded text-subtext">{t.sourceLang} → {t.targetLang}</span>
                        <span className="text-xs text-overlay1">{new Date(t.createdAt).toLocaleDateString('ar-SA')}</span>
                      </div>
                      <p className="text-text text-sm truncate">{t.sourceText}</p>
                    </div>
                  ))}
                  <a href="/history" className="block text-center text-lavender text-sm hover:underline mt-2 no-underline">
                    عرض الكل
                  </a>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  )
}
