import React, { useState, useEffect } from 'react'
import { useSearchParams } from 'react-router-dom'
import { motion } from 'framer-motion'
import { 
  Sparkles, Zap, Shield, Globe, BarChart3, Crown,
  ChevronLeft, Star, Users, ArrowUpRight
} from 'lucide-react'
import TranslationCard from '../components/TranslationCard'
import AuthModal from '../components/AuthModal'
import { useAuth } from '../contexts/AuthContext'

const features = [
  { icon: '🧠', title: 'ترجمة ذكية حقيقية', desc: 'ترجمة تفهم السياق والمعنى، لا مجرد كلمات' },
  { icon: '⚡', title: 'سرعة فائقة', desc: 'نتائج فورية في أقل من ثانية مهما كان حجم النص' },
  { icon: '🔒', title: 'نظام مصادقة آمن', desc: 'تسجيل دخول بالبريد مع حماية كاملة للبيانات' },
  { icon: '🌍', title: '30+ لغة', desc: 'دعم شامل مع اكتشاف تلقائي للغة المصدر' },
  { icon: '📊', title: 'إحصائيات متقدمة', desc: 'تتبع استخدامك والترجمات مع لوحة تحكم' },
  { icon: '🛡️', title: 'لوحة تحكم المدير', desc: 'إدارة متكاملة للمستخدمين والإحصائيات' },
]

const stats = [
  { num: '10K+', label: 'مستخدم نشط' },
  { num: '500K+', label: 'ترجمة ناجحة' },
  { num: '30+', label: 'لغة مدعومة' },
  { num: '99.9%', label: 'وقت التشغيل' },
]

const testimonials = [
  { name: 'أحمد المالكي', role: 'صاحب شركة ترجمة', text: 'غيّرت كهف AI Pro طريقة عملنا. نترجم 10 أضعاف ما كنا نترجمه قبلها.' },
  { name: 'سارة العتيبي', role: 'مسوقة رقمية', text: 'أفضل أداة ترجمة استخدمتها. الترجمة العربية دقيقة جداً والسعر معقول.' },
  { name: 'محمد الفهد', role: 'مطور تطبيقات', text: 'API سهل الاستخدام وتوثيق ممتاز. ربطته مع تطبيقي في ساعة واحدة.' },
]

export default function HomePage() {
  const [searchParams] = useSearchParams()
  const { isAuthenticated, user } = useAuth()
  const [authOpen, setAuthOpen] = useState(false)
  const [authTab, setAuthTab] = useState('login')

  useEffect(() => {
    const auth = searchParams.get('auth')
    if (auth) {
      setAuthTab(auth)
      setAuthOpen(true)
    }
  }, [searchParams])

  return (
    <div>
      <AuthModal isOpen={authOpen} onClose={() => setAuthOpen(false)} defaultTab={authTab} />

      {/* Hero Section */}
      <section className="relative min-h-screen flex flex-col items-center justify-center pt-16 overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_50%_at_50%_-20%,rgba(180,190,254,0.08)_0%,transparent_60%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_40%_at_80%_80%,rgba(203,166,247,0.05)_0%,transparent_50%)]" />
          <div 
            className="absolute inset-0 opacity-20"
            style={{
              backgroundImage: 'linear-gradient(rgba(180,190,254,0.04)_1px,transparent_1px),linear-gradient(90deg,rgba(180,190,254,0.04)_1px,transparent_1px)',
              backgroundSize: '40px 40px',
              maskImage: 'radial-gradient(ellipse_80%_80%_at_50%_50%,black_20%,transparent_80%)'
            }}
          />
        </div>

        <div className="relative z-10 w-full px-4">
          {/* Badge */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex justify-center mb-6"
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-lavender/10 border border-lavender/20 rounded-full text-lavender text-sm">
              <Crown size={14} />
              <span>منصة الترجمة الذكية الأكثر دقة</span>
            </div>
          </motion.div>

          {/* Title */}
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-6xl font-black text-white text-center mb-4 leading-tight"
          >
            ترجمة احترافية<br />
            بقوة <span className="text-lavender">كهف AI</span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-subtext text-center max-w-lg mx-auto mb-10 leading-relaxed"
          >
            أداة ترجمة ذكية تدعم أكثر من 30 لغة بدقة عالية، مدعومة بتقنيات الذكاء الاصطناعي الحديثة
          </motion.p>

          {/* Translation Card */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <TranslationCard />
          </motion.div>

          {/* Plan Badge */}
          {isAuthenticated && user && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex justify-center mt-6"
            >
              <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold ${
                user.plan === 'pro' ? 'bg-lavender/10 border border-lavender/30 text-lavender' :
                user.plan === 'business' ? 'bg-mauve/10 border border-mauve/30 text-mauve' :
                'bg-surface0 border border-surface1 text-subtext'
              }`}>
                <Star size={14} />
                {user.plan === 'free' ? 'الخطة المجانية - 500 حرف/يوم' : 
                 user.plan === 'pro' ? 'Pro - ترجمة غير محدودة' : 
                 'Business - API + ملفات'}
              </div>
            </motion.div>
          )}
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 px-4">
        <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6">
          {stats.map((stat, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="card text-center"
            >
              <div className="text-3xl font-black text-lavender mb-1">{stat.num}</div>
              <div className="text-subtext text-sm">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-base to-mantle">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-black text-white mb-3">لماذا كهف AI؟</h2>
            <p className="text-subtext">مميزات تجعلنا الخيار الأول للترجمة الذكية</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {features.map((f, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="card hover:border-lavender/40 hover:shadow-lg hover:shadow-lavender/5"
              >
                <div className="text-3xl mb-3">{f.icon}</div>
                <h3 className="text-white font-bold mb-2">{f.title}</h3>
                <p className="text-subtext text-sm leading-relaxed">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-black text-white mb-3">ماذا يقول عملاؤنا؟</h2>
            <p className="text-subtext">شهادات من مستخدمينا المميزين</p>
          </div>
          <div className="grid md:grid-cols-3 gap-5">
            {testimonials.map((t, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="card"
              >
                <div className="flex gap-1 mb-4">
                  {[1,2,3,4,5].map(s => (
                    <Star key={s} size={14} className="text-yellow fill-yellow" />
                  ))}
                </div>
                <p className="text-text text-sm leading-relaxed mb-4">"{t.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-lavender to-mauve rounded-full flex items-center justify-center text-base font-bold">
                    {t.name.charAt(0)}
                  </div>
                  <div>
                    <div className="text-white text-sm font-bold">{t.name}</div>
                    <div className="text-overlay1 text-xs">{t.role}</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="card bg-gradient-to-br from-lavender/5 to-mauve/5 border-lavender/20"
          >
            <h2 className="text-3xl font-black text-white mb-4">ابدأ الترجمة الذكية اليوم</h2>
            <p className="text-subtext mb-8 max-w-md mx-auto">
              انضم لآلاف المستخدمين الذين يثقون بكهف AI للترجمة الاحترافية. ابدأ مجاناً وارقِ عند الحاجة.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="/?auth=register" className="btn-primary inline-flex items-center justify-center gap-2 no-underline">
                ابدأ مجاناً <ArrowUpRight size={18} />
              </a>
              <a href="/pricing" className="btn-outline inline-flex items-center justify-center gap-2 no-underline">
                اكتشف الأسعار <ChevronLeft size={18} className="rotate-180" />
              </a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-crust border-t border-surface0 pt-16 pb-8 px-4">
        <div className="max-w-5xl mx-auto grid md:grid-cols-4 gap-8 mb-12">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <svg width="26" height="26" viewBox="0 0 32 32" fill="none">
                <path d="M16 2C10 2 6 8 6 14c0 4 2 8 4 10v4c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2v-4c2-2 4-6 4-10 0-6-4-12-10-12zm-4 28v-2h8v2h-8z" fill="#b4befe" opacity="0.9"/>
                <ellipse cx="16" cy="14" rx="4" ry="6" fill="#1e1e2e"/>
              </svg>
              <span className="text-white font-extrabold">كهف</span>
              <span className="text-overlay1 text-sm">AI</span>
            </div>
            <p className="text-subtext text-sm leading-relaxed max-w-sm">
              منصة الترجمة الذكية الأكثر دقة في العالم العربي، مدعومة بأحدث تقنيات الذكاء الاصطناعي
            </p>
          </div>
          <div>
            <h4 className="text-white font-bold text-sm mb-4">روابط سريعة</h4>
            <div className="space-y-2">
              <a href="/" className="block text-subtext hover:text-lavender text-sm transition-colors no-underline">الرئيسية</a>
              <a href="/pricing" className="block text-subtext hover:text-lavender text-sm transition-colors no-underline">الأسعار</a>
              <a href="/contact" className="block text-subtext hover:text-lavender text-sm transition-colors no-underline">تواصل معنا</a>
            </div>
          </div>
          <div>
            <h4 className="text-white font-bold text-sm mb-4">التواصل</h4>
            <div className="space-y-2">
              <a href="mailto:admin@kahf.ai" className="block text-subtext hover:text-lavender text-sm transition-colors no-underline">admin@kahf.ai</a>
              <a href="https://wa.me/966XXXXXXXXX" className="block text-subtext hover:text-lavender text-sm transition-colors no-underline">واتساب: +966XXXXXXXXX</a>
            </div>
          </div>
        </div>
        <div className="max-w-5xl mx-auto pt-6 border-t border-surface0 text-center">
          <p className="text-overlay1 text-xs">كهف AI Pro © 2026 — جميع الحقوق محفوظة</p>
        </div>
      </footer>
    </div>
  )
}
