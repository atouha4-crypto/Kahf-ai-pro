# كهف AI Pro - Frontend

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Copy environment variables
cp .env.example .env

# Edit .env with your API URL and Stripe key

# Start development server
npm run dev

# Build for production
npm run build
```

## 📁 Project Structure

```
src/
├── components/
│   ├── Navbar.jsx          # Navigation bar
│   ├── AuthModal.jsx       # Login/Register modal
│   └── TranslationCard.jsx   # Main translation interface
├── pages/
│   ├── HomePage.jsx         # Landing page with translation
│   ├── DashboardPage.jsx    # User dashboard
│   ├── AdminPage.jsx        # Admin dashboard
│   ├── PricingPage.jsx      # Pricing & plans
│   ├── ContactPage.jsx      # Contact form
│   └── TranslationHistoryPage.jsx # Translation history
├── contexts/
│   ├── AuthContext.jsx      # Authentication state
│   └── StripeContext.jsx    # Stripe integration
├── App.jsx                  # Main app component
├── main.jsx                 # Entry point
└── index.css                # Global styles + Tailwind
```

## 🎨 Design System

- **Theme**: Dark mode (Catppuccin Mocha)
- **Primary**: Lavender (#b4befe)
- **Secondary**: Mauve (#cba6f7)
- **Success**: Green (#a6e3a1)
- **Danger**: Red (#f38ba8)
- **Warning**: Peach (#fab387)

## 💳 Stripe Integration

1. Add your Stripe public key to `.env`
2. The backend handles checkout sessions
3. Webhooks update user plans automatically

## 📱 Responsive

- Mobile-first design
- Breakpoints: sm (640px), md (768px), lg (1024px)
- RTL support for Arabic

---
Built with ❤️ by كهف AI Team
