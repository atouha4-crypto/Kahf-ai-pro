# كهف AI Pro - Backend

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Copy environment variables
cp .env.example .env

# Edit .env with your credentials

# Start development server
npm run dev

# Start production server
npm start
```

## 📁 API Endpoints

### Auth
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login
- `POST /api/auth/refresh` - Refresh access token
- `POST /api/auth/logout` - Logout
- `GET /api/auth/me` - Get current user

### Translation
- `POST /api/translate` - Translate text
- `GET /api/translate/history` - Get translation history

### Payments (Stripe)
- `GET /api/plans` - Get available plans
- `POST /api/create-checkout-session` - Create Stripe checkout
- `POST /api/cancel-subscription` - Cancel subscription
- `POST /api/webhook` - Stripe webhook

### Admin
- `GET /api/admin/users` - List all users
- `GET /api/admin/stats` - Dashboard statistics
- `GET /api/admin/translations` - All translations
- `DELETE /api/admin/users/:id` - Delete user
- `GET /api/admin/contacts` - Contact form submissions

### Contact
- `POST /api/contact` - Submit contact form

## 💳 Stripe Setup

1. Create account at https://stripe.com
2. Get API keys from Dashboard
3. Add webhook endpoint: `https://your-domain.com/api/webhook`
4. Set webhook secret in .env

## 📱 WhatsApp Integration

Add WhatsApp Business API credentials to .env for automated notifications.

## 📧 Email Setup

Use Gmail App Password for email notifications.

---
Built with ❤️ by كهف AI Team
Contact: admin@kahf.ai | WhatsApp: +966XXXXXXXXX
