import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import { motion } from 'framer-motion'
import { Check, Sparkles, Zap, Crown, ArrowLeft, Loader2 } from 'lucide-react'

const plans = [
  {
    name: 'مجاني',
    price: 0,
    period: '',
    description: 'للاستخدام الشخصي البسيط',
    icon: Sparkles,
    color: 'subtext',
    features: [
      '500 حرف/يوم',
      '3 لغات أساسية',
      'ترجمة نصية فقط',
      'إعلانات',
      'دعم عبر البريد (48 ساعة)',
    ],
    notIncluded: [
      'ترجمة غير محدودة',
      '30+ لغة',
      'API للمطورين',
      'ترجمة الملفات',
      'دعم أولوية',
    ],
    cta: 'ابدأ مجاناً',
    popular: false,
  },
  {
    name: 'Pro',
    price: 9,
    period: '/شهر',
    description: 'للمحترفين والمستخدمين النشطين',
    icon: Zap,
    color: 'lavender',
    features: [
      'ترجمة غير محدودة',
      '30+ لغة كاملة',
      'بدون إعلانات',
      'سجل الترجمات',
      'دعم فني خلال 24 ساعة',
      'ترجمة أسرع',
    ],
    notIncluded: [
      'API للمطورين',
      'ترجمة الملفات',
    ],
    cta: 'اشترك الآن',
    popular: true,
  },
  {
    name: 'Business',
    price: 29,
    period: '/شهر',
    description: 'للشركات والفرق التقنية',
    icon: Crown,
    color: 'mauve',
    features: [
      'كل شيء في Pro',
      'API للمطورين',
      'ترجمة ملفات (PDF, Word)',
      'إدارة الفرق',
      'دعم أولوية فوري',
      'تخصيص White-label',
      'SLA مضمون 99.9%',
    ],
    notIncluded: [],
    cta: 'تواصل مع المبيعات',
    popular: false,
  },
]

export default function PricingPage() {
  const { user, isAuthenticated, api } = useAuth()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(null)

  const handleSubscribe = async (planName) => {
    if (!isAuthenticated) {
      navigate('/?auth=register')
      return
    }

    if (planName === 'Business') {
      window.open('https://wa.me/966XXXXXXXXX?text=مرحباً،%20أرغب%20في%20الترقية%20لخطة%20Business', '_blank')
      return
    }

    if (planName === 'مجاني') {
      navigate('/dashboard')
      return
    }

    setLoading(planName)
    try {
      const planKey = planName.toLowerCase()
      const response = await api.post('/create-checkout-session', { plan: planKey })
      window.location.href = response.data.url
    } catch (err) {
      alert('فشل إنشاء جلسة الدفع. حاول مرة أخرى.')
    } finally {
      setLoading(null)
    }
  }

  return (
    <div className="pt-24 pb-20 px-4 min-h-screen">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl font-black text-white mb-4"
          >
            اختر خطتك المثالية
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-subtext max-w-lg mx-auto"
          >
            ابدأ مجاناً وارقِ عندما تحتاج المزيد. لا رسوم خفية، إلغاء في أي وقت.
          </motion.p>
        </div>

        {/* Plans */}
        <div className="grid md:grid-cols-3 gap-6">
          {plans.map((plan, i) => {
            const Icon = plan.icon
            const isCurrentPlan = user?.plan === plan.name.toLowerCase()

            return (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.15 }}
                className={`relative card p-6 ${
                  plan.popular 
                    ? 'border-lavender/50 shadow-xl shadow-lavender/10 scale-105 z-10' 
                    : ''
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-lavender text-base text-xs font-bold rounded-full">
                    الأكثر شيوعاً
                  </div>
                )}

                <div className="flex items-center gap-3 mb-4">
                  <div className={`p-2 rounded-xl bg-${plan.color}/10`}>
                    <Icon size={24} className={`text-${plan.color}`} />
                  </div>
                  <div>
                    <h3 className="text-white font-bold text-lg">{plan.name}</h3>
                    <p className="text-overlay1 text-xs">{plan.description}</p>
                  </div>
                </div>

                <div className="mb-6">
                  <span className="text-4xl font-black text-white">${plan.price}</span>
                  <span className="text-subtext">{plan.period}</span>
                  {plan.price > 0 && (
                    <p className="text-overlay1 text-xs mt-1">أو ${plan.price * 10}/سنة (شهرين مجاناً)</p>
                  )}
                </div>

                <div className="space-y-3 mb-6">
                  {plan.features.map((feature, fi) => (
                    <div key={fi} className="flex items-center gap-2 text-sm">
                      <Check size={16} className="text-green shrink-0" />
                      <span className="text-text">{feature}</span>
                    </div>
                  ))}
                  {plan.notIncluded.map((feature, fi) => (
                    <div key={fi} className="flex items-center gap-2 text-sm opacity-50">
                      <div className="w-4 h-4 rounded-full border border-overlay1 flex items-center justify-center">
                        <span className="text-overlay1 text-xs">×</span>
                      </div>
                      <span className="text-overlay1">{feature}</span>
                    </div>
                  ))}
                </div>

                <button
                  onClick={() => handleSubscribe(plan.name)}
                  disabled={loading === plan.name || isCurrentPlan}
                  className={`w-full py-3 rounded-xl font-bold transition-all ${
                    isCurrentPlan 
                      ? 'bg-green/20 text-green border border-green/30 cursor-default'
                      : plan.popular
                      ? 'bg-lavender text-base hover:scale-[1.02] hover:shadow-lg hover:shadow-lavender/30'
                      : 'bg-surface0 text-text hover:bg-surface1'
                  } disabled:opacity-70`}
                >
                  {loading === plan.name ? (
                    <span className="inline-flex items-center gap-2">
                      <Loader2 size={16} className="animate-spin" />
                      جاري التحميل...
                    </span>
                  ) : isCurrentPlan ? (
                    'الخطة الحالية ✓'
                  ) : (
                    plan.cta
                  )}
                </button>
              </motion.div>
            )
          })}
        </div>

        {/* FAQ */}
        <div className="mt-20 max-w-2xl mx-auto">
          <h2 className="text-2xl font-bold text-white text-center mb-8">أسئلة شائعة</h2>
          <div className="space-y-4">
            {[
              { q: 'هل يمكنني الإلغاء في أي وقت؟', a: 'نعم، يمكنك الإلغاء في أي وقت من لوحة التحكم. لن تُفرض عليك رسوم إضافية.' },
              { q: 'ما الفرق بين Pro و Business؟', a: 'Business يشمل API للمطورين، ترجمة الملفات، وإدارة الفرق. Pro للاستخدام الشخصي المكثف.' },
              { q: 'هل هناك ضمان استرداد؟', a: 'نعم، استرداد كامل خلال 7 أيام إذا لم تكن راضياً عن الخدمة.' },
              { q: 'كيف أتواصل للدعم؟', a: 'Pro: خلال 24 ساعة عبر البريد. Business: دعم فوري عبر واتساب والبريد.' },
            ].map((faq, i) => (
              <div key={i} className="card p-5">
                <h3 className="text-white font-bold mb-2 flex items-center gap-2">
                  <ArrowLeft size={16} className="text-lavender" />
                  {faq.q}
                </h3>
                <p className="text-subtext text-sm leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
