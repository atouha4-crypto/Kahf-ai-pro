# 🏔️ كهف AI Pro - منصة الترجمة الذكية المتكاملة

<div align="center">

![Version](https://img.shields.io/badge/version-1.0.0-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![React](https://img.shields.io/badge/React-19-61DAFB)
![Node](https://img.shields.io/badge/Node-18+-339933)

**منصة الترجمة الذكية الأكثر دقة في العالم العربي**

[🌐 الموقع](https://kahf.ai) • [📧 البريد](mailto:admin@kahf.ai) • [📱 واتساب](https://wa.me/966XXXXXXXXX)

</div>

---

## ✨ المميزات

| الميزة | الوصف |
|--------|-------|
| 🧠 **ترجمة ذكية** | ترجمة تفهم السياق العربي بدقة عالية |
| ⚡ **سرعة فائقة** | نتائج فورية مهما كان حجم النص |
| 🌍 **30+ لغة** | دعم شامل مع اكتشاف تلقائي |
| 💳 **اشتراكات مرنة** | Freemium: مجاني / Pro / Business |
| 🔒 **نظام أمان** | JWT + bcrypt + rate limiting |
| 📊 **لوحة تحكم** | إحصائيات وتحليلات في الوقت الفعلي |
| 🤖 **API للمطورين** | REST API كامل للتكامل |
| 📱 **تواصل مباشر** | بريد + واتساب + تيليجرام |

---

## 🚀 التشغيل السريع

### المتطلبات
- Node.js 18+
- MongoDB 5+
- Stripe account (للمدفوعات)

### 1. Clone & Install

```bash
git clone https://github.com/yourusername/kahf-ai-pro.git
cd kahf-ai-pro

# Backend
cd backend
npm install
cp .env.example .env
# Edit .env with your credentials
npm run dev

# Frontend (terminal جديد)
cd frontend
npm install
cp .env.example .env
# Edit .env with your API URL
npm run dev
```

### 2. الوصول
- 🌐 Frontend: http://localhost:3000
- 🔌 API: http://localhost:5000/api
- 📊 Admin: سجل دخول بـ `admin@kahf.ai` / `Admin@2026`

---

## 💰 نموذج الدخل

| الخطة | السعر | المميزات |
|-------|-------|---------|
| **مجاني** | $0 | 500 حرف/يوم، 3 لغات |
| **Pro** | $9/شهر | ترجمة غير محدودة، 30+ لغة |
| **Business** | $29/شهر | API + ملفات + فريق + دعم أولوية |

---

## 📁 هيكل المشروع

```
kahf-ai-pro/
├── backend/
│   ├── server.js           # Express server
│   ├── package.json
│   ├── .env.example
│   └── README.md
├── frontend/
│   ├── src/
│   │   ├── components/     # React components
│   │   ├── pages/          # Page components
│   │   ├── contexts/       # React contexts
│   │   ├── App.jsx
│   │   └── index.css
│   ├── package.json
│   ├── vite.config.js
│   ├── tailwind.config.js
│   └── README.md
└── README.md
```

---

## 🔧 التكوين

### متغيرات البيئة (Backend)

```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/kahf_ai_pro
JWT_ACCESS_SECRET=your-strong-secret
JWT_REFRESH_SECRET=your-strong-refresh-secret
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
CLIENT_URL=http://localhost:3000
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=your-app-password
```

### متغيرات البيئة (Frontend)

```env
VITE_API_URL=http://localhost:5000/api
VITE_STRIPE_PUBLIC_KEY=pk_test_...
```

---

## 📱 التواصل والدعم

| القناة | الرابط | الاستجابة |
|--------|--------|----------|
| 📧 البريد | [admin@kahf.ai](mailto:admin@kahf.ai) | 24 ساعة |
| 📱 واتساب | [+966 XX XXX XXXX](https://wa.me/966XXXXXXXXX) | فوري (Business) |
| 💬 تيليجرام | [@kahf_ai_support](https://t.me/kahf_ai_support) | تحديثات |

---

## 🛡️ الأمان

- ✅ JWT tokens مع refresh tokens
- ✅ bcrypt hashing للكلمات المرورية
- ✅ Rate limiting على جميع endpoints
- ✅ Helmet.js للحماية من XSS
- ✅ CORS configured
- ✅ Input validation
- ✅ MongoDB injection protection

---

## 📜 الترخيص

MIT License - استخدمه كما تشاء مع الإشارة للمصدر.

---

<div align="center">

**Built with ❤️ by كهف AI Team**

© 2026 كهف AI Pro. جميع الحقوق محفوظة.

</div>
