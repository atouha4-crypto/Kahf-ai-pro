import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import { motion } from 'framer-motion'
import { 
  ArrowLeft, Loader2, Copy, Volume2, Trash2, 
  ChevronLeft, ChevronRight, Search, Filter
} from 'lucide-react'

export default function TranslationHistoryPage() {
  const { user, isAuthenticated, loading: authLoading, api } = useAuth()
  const navigate = useNavigate()
  const [translations, setTranslations] = useState([])
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [search, setSearch] = useState('')
  const [copiedId, setCopiedId] = useState(null)

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      navigate('/?auth=login')
    }
  }, [authLoading, isAuthenticated, navigate])

  useEffect(() => {
    if (isAuthenticated) fetchHistory()
  }, [isAuthenticated, page])

  const fetchHistory = async () => {
    setLoading(true)
    try {
      const response = await api.get(`/translate/history?page=${page}&limit=10`)
      setTranslations(response.data.translations)
      setTotalPages(response.data.totalPages)
    } catch (err) {
      console.error('History error:', err)
    } finally {
      setLoading(false)
    }
  }

  const handleCopy = async (text, id) => {
    await navigator.clipboard.writeText(text)
    setCopiedId(id)
    setTimeout(() => setCopiedId(null), 2000)
  }

  const handleSpeak = (text, lang) => {
    if (!window.speechSynthesis) return
    const utterance = new SpeechSynthesisUtterance(text)
    utterance.lang = lang === 'ar' ? 'ar-SA' : lang
    speechSynthesis.speak(utterance)
  }

  const filteredTranslations = translations.filter(t => 
    t.sourceText.toLowerCase().includes(search.toLowerCase()) ||
    t.translatedText.toLowerCase().includes(search.toLowerCase())
  )

  if (authLoading || loading) {
    return (
      <div className="pt-24 flex items-center justify-center min-h-screen">
        <Loader2 size={40} className="text-lavender animate-spin" />
      </div>
    )
  }

  if (!isAuthenticated) return null

  return (
    <div className="pt-24 pb-20 px-4 min-h-screen">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-4 mb-2">
            <button 
              onClick={() => navigate('/dashboard')}
              className="p-2 hover:bg-surface0 rounded-lg transition-colors"
            >
              <ArrowLeft size={20} className="text-subtext" />
            </button>
            <h1 className="text-3xl font-black text-white">سجل الترجمات</h1>
          </div>
          <p className="text-subtext">جميع ترجماتك المحفوظة</p>
        </motion.div>

        {/* Search */}
        <div className="card mb-6">
          <div className="relative">
            <Search size={18} className="absolute right-4 top-1/2 -translate-y-1/2 text-overlay1" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="input-field pr-12"
              placeholder="ابحث في الترجمات..."
            />
          </div>
        </div>

        {/* Translations List */}
        <div className="space-y-4">
          {filteredTranslations.length === 0 ? (
            <div className="card text-center py-16">
              <Filter size={48} className="mx-auto mb-4 text-overlay1" />
              <h3 className="text-white font-bold text-lg mb-2">
                {search ? 'لا توجد نتائج للبحث' : 'لا توجد ترجمات بعد'}
              </h3>
              <p className="text-subtext">
                {search ? 'جرب كلمات بحث مختلفة' : 'ابدأ الترجمة من الصفحة الرئيسية'}
              </p>
              {!search && (
                <a href="/" className="btn-primary inline-block mt-4 no-underline">
                  ابدأ الترجمة
                </a>
              )}
            </div>
          ) : (
            filteredTranslations.map((t, i) => (
              <motion.div
                key={t._id || i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="card hover:border-lavender/30"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <span className="px-3 py-1 bg-surface0 rounded-full text-xs font-bold text-lavender">
                      {t.sourceLang} → {t.targetLang}
                    </span>
                    <span className="text-overlay1 text-xs">
                      {new Date(t.createdAt).toLocaleString('ar-SA')}
                    </span>
                    <span className="text-overlay1 text-xs">
                      {t.charactersCount} حرف
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    <button 
                      onClick={() => handleCopy(t.translatedText, t._id || i)}
                      className="p-2 hover:bg-surface0 rounded-lg transition-colors text-subtext hover:text-lavender"
                      title="نسخ"
                    >
                      {copiedId === (t._id || i) ? <Check size={16} className="text-green" /> : <Copy size={16} />}
                    </button>
                    <button 
                      onClick={() => handleSpeak(t.translatedText, t.targetLang)}
                      className="p-2 hover:bg-surface0 rounded-lg transition-colors text-subtext hover:text-lavender"
                      title="استمع"
                    >
                      <Volume2 size={16} />
                    </button>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-3 bg-crust rounded-xl">
                    <p className="text-overlay1 text-xs mb-1">النص الأصلي</p>
                    <p className="text-text text-sm leading-relaxed">{t.sourceText}</p>
                  </div>
                  <div className="p-3 bg-crust rounded-xl">
                    <p className="text-overlay1 text-xs mb-1">الترجمة</p>
                    <p className="text-text text-sm leading-relaxed">{t.translatedText}</p>
                  </div>
                </div>
              </motion.div>
            ))
          )}
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-3 mt-8">
            <button
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page === 1}
              className="p-2 bg-surface0 rounded-lg hover:bg-surface1 transition-colors disabled:opacity-50"
            >
              <ChevronRight size={18} />
            </button>
            <span className="text-subtext text-sm">
              صفحة {page} من {totalPages}
            </span>
            <button
              onClick={() => setPage(p => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="p-2 bg-surface0 rounded-lg hover:bg-surface1 transition-colors disabled:opacity-50"
            >
              <ChevronLeft size={18} />
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
