import React, { useState, useEffect, useRef } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { 
  Trash2, Copy, Volume2, ArrowLeftRight, ChevronDown, 
  Sparkles, AlertTriangle, Check
} from 'lucide-react'

const LANGUAGES = [
  { code: 'auto', label: 'كشف تلقائي', flag: '🔍' },
  { code: 'ar', label: 'العربية', flag: '🇸🇦' },
  { code: 'en', label: 'الإنجليزية', flag: '🇬🇧' },
  { code: 'fr', label: 'الفرنسية', flag: '🇫🇷' },
  { code: 'es', label: 'الإسبانية', flag: '🇪🇸' },
  { code: 'de', label: 'الألمانية', flag: '🇩🇪' },
  { code: 'tr', label: 'التركية', flag: '🇹🇷' },
  { code: 'zh', label: 'الصينية', flag: '🇨🇳' },
  { code: 'ja', label: 'اليابانية', flag: '🇯🇵' },
  { code: 'ru', label: 'الروسية', flag: '🇷🇺' },
  { code: 'pt', label: 'البرتغالية', flag: '🇵🇹' },
  { code: 'it', label: 'الإيطالية', flag: '🇮🇹' },
  { code: 'nl', label: 'الهولندية', flag: '🇳🇱' },
  { code: 'ko', label: 'الكورية', flag: '🇰🇷' },
  { code: 'fa', label: 'الفارسية', flag: '🇮🇷' },
  { code: 'ur', label: 'الأردية', flag: '🇵🇰' },
  { code: 'he', label: 'العبرية', flag: '🇮🇱' },
  { code: 'sv', label: 'السويدية', flag: '🇸🇪' },
  { code: 'pl', label: 'البولندية', flag: '🇵🇱' },
  { code: 'id', label: 'الإندونيسية', flag: '🇮🇩' },
]

export default function TranslationCard() {
  const { user, isAuthenticated, api } = useAuth()
  const [inputText, setInputText] = useState('')
  const [outputText, setOutputText] = useState('')
  const [sourceLang, setSourceLang] = useState('ar')
  const [targetLang, setTargetLang] = useState('en')
  const [loading, setLoading] = useState(false)
  const [copied, setCopied] = useState(false)
  const [showSourceDropdown, setShowSourceDropdown] = useState(false)
  const [showTargetDropdown, setShowTargetDropdown] = useState(false)
  const [limitWarning, setLimitWarning] = useState(null)

  const sourceRef = useRef(null)
  const targetRef = useRef(null)

  useEffect(() => {
    function handleClickOutside(e) {
      if (sourceRef.current && !sourceRef.current.contains(e.target)) setShowSourceDropdown(false)
      if (targetRef.current && !targetRef.current.contains(e.target)) setShowTargetDropdown(false)
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const getLang = (code) => LANGUAGES.find(l => l.code === code)

  const handleTranslate = async () => {
    if (!inputText.trim()) return

    if (!isAuthenticated) {
      setLimitWarning({ type: 'auth', message: 'سجّل دخولك للترجمة. الخطة المجانية: 500 حرف/يوم' })
      return
    }

    setLoading(true)
    setLimitWarning(null)

    try {
      const response = await api.post('/translate', {
        text: inputText,
        sourceLang,
        targetLang
      })

      setOutputText(response.data.translatedText)
      if (response.data.remaining !== 'unlimited') {
        setLimitWarning({ 
          type: 'success', 
          message: `متبقي: ${response.data.remaining} حرف اليوم` 
        })
      }
    } catch (err) {
      if (err.response?.status === 403) {
        setLimitWarning({ 
          type: 'limit', 
          message: 'لقد تجاوزت الحد اليومي. اترقِ إلى Pro للترجمة غير المحدودة!' 
        })
      } else {
        setLimitWarning({ type: 'error', message: 'فشلت الترجمة. حاول مرة أخرى.' })
      }
    } finally {
      setLoading(false)
    }
  }

  const handleSwap = () => {
    if (sourceLang === 'auto') {
      setLimitWarning({ type: 'error', message: 'لا يمكن التبديل مع الكشف التلقائي' })
      return
    }
    const temp = sourceLang
    setSourceLang(targetLang)
    setTargetLang(temp)
    setInputText(outputText)
    setOutputText(inputText)
  }

  const handleCopy = async () => {
    if (!outputText) return
    await navigator.clipboard.writeText(outputText)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleSpeak = () => {
    if (!outputText || !window.speechSynthesis) return
    const utterance = new SpeechSynthesisUtterance(outputText)
    utterance.lang = targetLang === 'ar' ? 'ar-SA' : targetLang
    speechSynthesis.speak(utterance)
  }

  const handleClear = () => {
    setInputText('')
    setOutputText('')
    setLimitWarning(null)
  }

  const charCount = inputText.length

  return (
    <div className="w-full max-w-3xl mx-auto">
      {/* Limit Warning */}
      {limitWarning && (
        <div className={`mb-4 p-3 rounded-xl text-sm font-medium flex items-center gap-2 ${
          limitWarning.type === 'limit' ? 'bg-peach/10 border border-peach/30 text-peach' :
          limitWarning.type === 'auth' ? 'bg-blue/10 border border-blue/30 text-blue' :
          limitWarning.type === 'success' ? 'bg-green/10 border border-green/30 text-green' :
          'bg-red/10 border border-red/30 text-red'
        }`}>
          {limitWarning.type === 'limit' && <AlertTriangle size={16} />}
          {limitWarning.type === 'auth' && <Sparkles size={16} />}
          {limitWarning.type === 'success' && <Check size={16} />}
          {limitWarning.message}
        </div>
      )}

      <div className="card overflow-hidden">
        {/* Toolbar */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-surface0 bg-black/10">
          <div className="flex items-center gap-1">
            <button onClick={handleClear} className="p-2 rounded-lg hover:bg-surface0 text-subtext hover:text-red transition-all" title="مسح الكل">
              <Trash2 size={18} />
            </button>
            <button onClick={handleCopy} className="p-2 rounded-lg hover:bg-surface0 text-subtext hover:text-lavender transition-all" title="نسخ">
              {copied ? <Check size={18} className="text-green" /> : <Copy size={18} />}
            </button>
            <button onClick={handleSpeak} className="p-2 rounded-lg hover:bg-surface0 text-subtext hover:text-lavender transition-all" title="استمع">
              <Volume2 size={18} />
            </button>
          </div>
          <span className="text-xs text-overlay1">{charCount} حرف</span>
        </div>

        {/* Input Area */}
        <div className="p-4">
          <textarea
            value={inputText}
            onChange={e => setInputText(e.target.value)}
            className="w-full h-36 bg-transparent border-none outline-none resize-none text-text placeholder-overlay0 text-base leading-relaxed"
            placeholder="اكتب النص هنا للترجمة..."
            dir="auto"
          />
        </div>

        {/* Language Bar */}
        <div className="flex items-center justify-center gap-3 px-4 py-3 border-y border-surface0">
          {/* Source */}
          <div className="relative" ref={sourceRef}>
            <button 
              onClick={() => { setShowSourceDropdown(!showSourceDropdown); setShowTargetDropdown(false) }}
              className="flex items-center gap-2 px-4 py-2 bg-crust border border-surface0 rounded-lg hover:border-lavender transition-all"
            >
              <span>{getLang(sourceLang)?.flag}</span>
              <span className="text-sm">{getLang(sourceLang)?.label}</span>
              <ChevronDown size={14} className="text-overlay1" />
            </button>
            {showSourceDropdown && (
              <div className="absolute top-full right-0 mt-2 w-52 bg-crust border border-surface0 rounded-xl shadow-2xl max-h-72 overflow-y-auto z-30">
                {LANGUAGES.map(lang => (
                  <button
                    key={lang.code}
                    onClick={() => { setSourceLang(lang.code); setShowSourceDropdown(false) }}
                    className={`flex items-center gap-3 w-full px-4 py-2.5 text-right hover:bg-surface0 transition-colors ${
                      sourceLang === lang.code ? 'text-lavender bg-lavender/5' : 'text-text'
                    }`}
                  >
                    <span>{lang.flag}</span>
                    <span className="text-sm">{lang.label}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Swap */}
          <button 
            onClick={handleSwap}
            className="p-2.5 rounded-full bg-surface0 hover:bg-lavender hover:text-base text-subtext transition-all hover:rotate-180"
          >
            <ArrowLeftRight size={18} />
          </button>

          {/* Target */}
          <div className="relative" ref={targetRef}>
            <button 
              onClick={() => { setShowTargetDropdown(!showTargetDropdown); setShowSourceDropdown(false) }}
              className="flex items-center gap-2 px-4 py-2 bg-crust border border-surface0 rounded-lg hover:border-lavender transition-all"
            >
              <span>{getLang(targetLang)?.flag}</span>
              <span className="text-sm">{getLang(targetLang)?.label}</span>
              <ChevronDown size={14} className="text-overlay1" />
            </button>
            {showTargetDropdown && (
              <div className="absolute top-full left-0 mt-2 w-52 bg-crust border border-surface0 rounded-xl shadow-2xl max-h-72 overflow-y-auto z-30">
                {LANGUAGES.filter(l => l.code !== 'auto').map(lang => (
                  <button
                    key={lang.code}
                    onClick={() => { setTargetLang(lang.code); setShowTargetDropdown(false) }}
                    className={`flex items-center gap-3 w-full px-4 py-2.5 text-right hover:bg-surface0 transition-colors ${
                      targetLang === lang.code ? 'text-lavender bg-lavender/5' : 'text-text'
                    }`}
                  >
                    <span>{lang.flag}</span>
                    <span className="text-sm">{lang.label}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Output Area */}
        <div className="p-4 bg-black/5">
          <textarea
            value={outputText}
            readOnly
            className="w-full h-28 bg-crust border border-surface0 rounded-xl p-3 text-text placeholder-overlay0 text-base leading-relaxed resize-none outline-none"
            placeholder="ستظهر الترجمة هنا..."
            dir="auto"
          />
        </div>

        {/* Translate Button */}
        <div className="p-4 pt-2">
          <button
            onClick={handleTranslate}
            disabled={loading || !inputText.trim()}
            className="w-full py-3.5 bg-lavender text-base font-extrabold rounded-xl hover:scale-[1.01] hover:shadow-xl hover:shadow-lavender/30 transition-all disabled:opacity-50 disabled:hover:scale-100 flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <span className="w-5 h-5 border-2 border-base/30 border-t-base rounded-full animate-spin" />
                جاري الترجمة...
              </>
            ) : (
              <>ترجم الآن <Sparkles size={18} /></>
            )}
          </button>
        </div>
      </div>
    </div>
  )
}
