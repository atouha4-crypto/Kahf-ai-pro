const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const nodemailer = require('nodemailer');
const axios = require('axios');
const multer = require('multer');
const { body, validationResult } = require('express-validator');
require('dotenv').config();

const app = express();

// Security middleware
app.use(helmet());
app.use(compression());
app.use(morgan('combined'));

// CORS configuration
app.use(cors({
  origin: process.env.CLIENT_URL || 'http://localhost:3000',
  credentials: true
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
});
app.use(limiter);

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { error: 'Too many attempts. Please try again later.' }
});

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// MongoDB Connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/kahf_ai_pro', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('✅ MongoDB Connected'))
.catch(err => console.error('❌ MongoDB Error:', err));

// ====================================================
// SCHEMAS
// ====================================================

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['user', 'admin'], default: 'user' },
  plan: { type: String, enum: ['free', 'pro', 'business'], default: 'free' },
  stripeCustomerId: { type: String },
  stripeSubscriptionId: { type: String },
  translationsCount: { type: Number, default: 0 },
  translationsLimit: { type: Number, default: 500 }, // characters per day for free
  charactersUsed: { type: Number, default: 0 },
  lastResetDate: { type: Date, default: Date.now },
  createdAt: { type: Date, default: Date.now },
  lastLogin: { type: Date },
  isActive: { type: Boolean, default: true },
  refreshToken: { type: String },
});

const translationSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  userEmail: { type: String },
  sourceText: { type: String, required: true },
  translatedText: { type: String, required: true },
  sourceLang: { type: String, required: true },
  targetLang: { type: String, required: true },
  charactersCount: { type: Number },
  createdAt: { type: Date, default: Date.now },
});

const paymentSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  stripePaymentIntentId: { type: String },
  stripeSubscriptionId: { type: String },
  amount: { type: Number, required: true },
  currency: { type: String, default: 'usd' },
  status: { type: String, enum: ['pending', 'completed', 'failed', 'cancelled'], default: 'pending' },
  plan: { type: String, enum: ['pro', 'business'] },
  createdAt: { type: Date, default: Date.now },
});

const contactSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true },
  phone: { type: String },
  message: { type: String, required: true },
  source: { type: String, enum: ['email', 'whatsapp', 'website'], default: 'website' },
  status: { type: String, enum: ['new', 'read', 'replied', 'archived'], default: 'new' },
  createdAt: { type: Date, default: Date.now },
});

const User = mongoose.model('User', userSchema);
const Translation = mongoose.model('Translation', translationSchema);
const Payment = mongoose.model('Payment', paymentSchema);
const Contact = mongoose.model('Contact', contactSchema);

// ====================================================
// JWT UTILS
// ====================================================

const generateAccessToken = (user) => {
  return jwt.sign(
    { sub: user._id, email: user.email, role: user.role, plan: user.plan },
    process.env.JWT_ACCESS_SECRET || 'kahf-access-secret-2026',
    { expiresIn: '15m', algorithm: 'HS256' }
  );
};

const generateRefreshToken = (user) => {
  return jwt.sign(
    { sub: user._id, type: 'refresh' },
    process.env.JWT_REFRESH_SECRET || 'kahf-refresh-secret-2026',
    { expiresIn: '7d', algorithm: 'HS256' }
  );
};

const verifyAccessToken = (token) => {
  return jwt.verify(token, process.env.JWT_ACCESS_SECRET || 'kahf-access-secret-2026', {
    algorithms: ['HS256']
  });
};

// ====================================================
// MIDDLEWARE
// ====================================================

const authMiddleware = async (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'No token provided' });
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = verifyAccessToken(token);
    const user = await User.findById(decoded.sub);
    if (!user || !user.isActive) {
      return res.status(401).json({ message: 'User not found or inactive' });
    }
    req.user = user;
    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ message: 'Token expired', code: 'TOKEN_EXPIRED' });
    }
    return res.status(401).json({ message: 'Invalid token' });
  }
};

const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ message: 'Not authenticated' });
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ message: 'Insufficient permissions' });
    }
    next();
  };
};

// ====================================================
// AUTH ROUTES
// ====================================================

app.post('/api/auth/register', authLimiter, [
  body('name').trim().isLength({ min: 2 }).withMessage('Name must be at least 2 characters'),
  body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
  body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { name, email, password } = req.body;

  try {
    const existingUser = await User.findOne({ email: email.toLowerCase() });
    if (existingUser) {
      return res.status(400).json({ message: 'Email already registered' });
    }

    const hashedPassword = await bcrypt.hash(password, 12);
    const role = email.toLowerCase() === 'admin@kahf.ai' ? 'admin' : 'user';

    const user = new User({
      name,
      email: email.toLowerCase(),
      password: hashedPassword,
      role,
      plan: 'free',
      translationsLimit: 500,
    });

    await user.save();

    const accessToken = generateAccessToken(user);
    const refreshToken = generateRefreshToken(user);

    user.refreshToken = await bcrypt.hash(refreshToken, 10);
    await user.save();

    res.cookie('refreshToken', refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60 * 1000,
      path: '/api/auth',
    });

    res.status(201).json({
      accessToken,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        plan: user.plan,
      }
    });
  } catch (error) {
    console.error('Register error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

app.post('/api/auth/login', authLimiter, async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password required' });
  }

  try {
    const user = await User.findOne({ email: email.toLowerCase() }).select('+password');
    if (!user) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    user.lastLogin = new Date();
    await user.save();

    const accessToken = generateAccessToken(user);
    const refreshToken = generateRefreshToken(user);

    user.refreshToken = await bcrypt.hash(refreshToken, 10);
    await user.save();

    res.cookie('refreshToken', refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60 * 1000,
      path: '/api/auth',
    });

    res.json({
      accessToken,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        plan: user.plan,
        translationsCount: user.translationsCount,
        charactersUsed: user.charactersUsed,
        translationsLimit: user.translationsLimit,
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

app.post('/api/auth/refresh', async (req, res) => {
  const refreshToken = req.cookies?.refreshToken;
  if (!refreshToken) {
    return res.status(401).json({ message: 'No refresh token' });
  }

  try {
    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET || 'kahf-refresh-secret-2026', {
      algorithms: ['HS256']
    });

    const user = await User.findById(decoded.sub);
    if (!user) {
      return res.status(401).json({ message: 'User not found' });
    }

    const isValid = await bcrypt.compare(refreshToken, user.refreshToken || '');
    if (!isValid) {
      return res.status(401).json({ message: 'Invalid refresh token' });
    }

    const newAccessToken = generateAccessToken(user);
    res.json({ accessToken: newAccessToken });
  } catch (error) {
    res.status(401).json({ message: 'Invalid refresh token' });
  }
});

app.post('/api/auth/logout', authMiddleware, async (req, res) => {
  try {
    req.user.refreshToken = null;
    await req.user.save();
    res.clearCookie('refreshToken', { path: '/api/auth' });
    res.json({ message: 'Logged out successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Logout failed' });
  }
});

app.get('/api/auth/me', authMiddleware, async (req, res) => {
  res.json({
    user: {
      id: req.user._id,
      name: req.user.name,
      email: req.user.email,
      role: req.user.role,
      plan: req.user.plan,
      translationsCount: req.user.translationsCount,
      charactersUsed: req.user.charactersUsed,
      translationsLimit: req.user.translationsLimit,
      createdAt: req.user.createdAt,
    }
  });
});

// ====================================================
// TRANSLATION ROUTES
// ====================================================

app.post('/api/translate', authMiddleware, async (req, res) => {
  const { text, sourceLang, targetLang } = req.body;

  if (!text || !targetLang) {
    return res.status(400).json({ message: 'Text and target language required' });
  }

  const charCount = text.length;

  // Check plan limits
  if (req.user.plan === 'free') {
    // Reset daily counter if needed
    const today = new Date();
    const lastReset = new Date(req.user.lastResetDate);
    if (today.toDateString() !== lastReset.toDateString()) {
      req.user.charactersUsed = 0;
      req.user.lastResetDate = today;
    }

    if (req.user.charactersUsed + charCount > req.user.translationsLimit) {
      return res.status(403).json({
        message: 'Daily limit reached. Upgrade to Pro for unlimited translations.',
        upgradeUrl: '/pricing',
        currentUsage: req.user.charactersUsed,
        limit: req.user.translationsLimit,
      });
    }
  }

  try {
    // MyMemory API (free tier)
    const src = sourceLang === 'auto' ? 'ar' : sourceLang;
    const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${src}|${targetLang}`;

    const response = await axios.get(url, { timeout: 10000 });
    const data = response.data;

    if (data.responseStatus === 200 && data.responseData?.translatedText) {
      const translated = data.responseData.translatedText;

      // Update user stats
      req.user.translationsCount += 1;
      req.user.charactersUsed += charCount;
      await req.user.save();

      // Save translation
      const translation = new Translation({
        userId: req.user._id,
        userEmail: req.user.email,
        sourceText: text,
        translatedText: translated,
        sourceLang: src,
        targetLang,
        charactersCount: charCount,
      });
      await translation.save();

      res.json({
        translatedText: translated,
        sourceLang: src,
        targetLang,
        charactersCount: charCount,
        remaining: req.user.plan === 'free' ? req.user.translationsLimit - req.user.charactersUsed : 'unlimited',
      });
    } else {
      throw new Error('Translation service error');
    }
  } catch (error) {
    console.error('Translation error:', error);
    res.status(500).json({ message: 'Translation failed. Please try again.' });
  }
});

app.get('/api/translate/history', authMiddleware, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;

    const translations = await Translation.find({ userId: req.user._id })
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit);

    const total = await Translation.countDocuments({ userId: req.user._id });

    res.json({ translations, total, page, totalPages: Math.ceil(total / limit) });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch history' });
  }
});

// ====================================================
// STRIPE PAYMENT ROUTES
// ====================================================

const PLANS = {
  pro: {
    name: 'Pro',
    price: 900, // $9.00 in cents
    interval: 'month',
    features: ['Unlimited translations', '30+ languages', 'No ads', 'Priority support'],
  },
  business: {
    name: 'Business',
    price: 2900, // $29.00 in cents
    interval: 'month',
    features: ['Everything in Pro', 'API access', 'File translation', 'Dedicated support', 'Team management'],
  },
};

app.get('/api/plans', async (req, res) => {
  res.json({ plans: PLANS });
});

app.post('/api/create-checkout-session', authMiddleware, async (req, res) => {
  const { plan } = req.body;

  if (!PLANS[plan]) {
    return res.status(400).json({ message: 'Invalid plan' });
  }

  try {
    let customer = req.user.stripeCustomerId;

    if (!customer) {
      const stripeCustomer = await stripe.customers.create({
        email: req.user.email,
        name: req.user.name,
        metadata: { userId: req.user._id.toString() },
      });
      customer = stripeCustomer.id;
      req.user.stripeCustomerId = customer;
      await req.user.save();
    }

    const session = await stripe.checkout.sessions.create({
      customer,
      payment_method_types: ['card'],
      line_items: [{
        price_data: {
          currency: 'usd',
          product_data: {
            name: `كهف AI - ${PLANS[plan].name} Plan`,
            description: PLANS[plan].features.join(', '),
          },
          unit_amount: PLANS[plan].price,
          recurring: { interval: PLANS[plan].interval },
        },
        quantity: 1,
      }],
      mode: 'subscription',
      success_url: `${process.env.CLIENT_URL}/dashboard?success=true&plan=${plan}`,
      cancel_url: `${process.env.CLIENT_URL}/pricing?canceled=true`,
      metadata: { userId: req.user._id.toString(), plan },
    });

    res.json({ sessionId: session.id, url: session.url });
  } catch (error) {
    console.error('Stripe error:', error);
    res.status(500).json({ message: 'Payment setup failed' });
  }
});

app.post('/api/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'];
  const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;

  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, endpointSecret);
  } catch (err) {
    console.error('Webhook error:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const userId = session.metadata.userId;
    const plan = session.metadata.plan;

    try {
      const user = await User.findById(userId);
      if (user) {
        user.plan = plan;
        user.stripeSubscriptionId = session.subscription;
        user.translationsLimit = plan === 'business' ? 1000000 : 100000;
        await user.save();

        const payment = new Payment({
          userId: user._id,
          stripeSubscriptionId: session.subscription,
          amount: PLANS[plan].price / 100,
          currency: 'usd',
          status: 'completed',
          plan,
        });
        await payment.save();
      }
    } catch (error) {
      console.error('Webhook processing error:', error);
    }
  }

  if (event.type === 'invoice.payment_failed') {
    const subscription = event.data.object;
    const user = await User.findOne({ stripeSubscriptionId: subscription.id });
    if (user) {
      user.plan = 'free';
      user.translationsLimit = 500;
      await user.save();
    }
  }

  res.json({ received: true });
});

app.post('/api/cancel-subscription', authMiddleware, async (req, res) => {
  try {
    if (!req.user.stripeSubscriptionId) {
      return res.status(400).json({ message: 'No active subscription' });
    }

    await stripe.subscriptions.update(req.user.stripeSubscriptionId, {
      cancel_at_period_end: true,
    });

    res.json({ message: 'Subscription will cancel at period end' });
  } catch (error) {
    console.error('Cancel error:', error);
    res.status(500).json({ message: 'Failed to cancel subscription' });
  }
});

// ====================================================
// ADMIN ROUTES
// ====================================================

app.get('/api/admin/users', authMiddleware, authorize('admin'), async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 50;

    const users = await User.find()
      .select('-password -refreshToken')
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit);

    const total = await User.countDocuments();

    res.json({ users, total, page, totalPages: Math.ceil(total / limit) });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch users' });
  }
});

app.get('/api/admin/stats', authMiddleware, authorize('admin'), async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();
    const totalTranslations = await Translation.countDocuments();
    const totalRevenue = await Payment.aggregate([
      { $match: { status: 'completed' } },
      { $group: { _id: null, total: { $sum: '$amount' } } }
    ]);
    const activeUsers = await User.countDocuments({ lastLogin: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) } });

    const dailyStats = await Translation.aggregate([
      {
        $group: {
          _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
          count: { $sum: 1 },
        }
      },
      { $sort: { _id: -1 } },
      { $limit: 7 }
    ]);

    res.json({
      totalUsers,
      totalTranslations,
      totalRevenue: totalRevenue[0]?.total || 0,
      activeUsers,
      dailyStats,
    });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch stats' });
  }
});

app.get('/api/admin/translations', authMiddleware, authorize('admin'), async (req, res) => {
  try {
    const translations = await Translation.find()
      .sort({ createdAt: -1 })
      .limit(100)
      .populate('userId', 'name email');

    res.json({ translations });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch translations' });
  }
});

app.delete('/api/admin/users/:id', authMiddleware, authorize('admin'), async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: 'User not found' });
    if (user.role === 'admin') return res.status(403).json({ message: 'Cannot delete admin' });

    await User.findByIdAndDelete(req.params.id);
    res.json({ message: 'User deleted' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete user' });
  }
});

// ====================================================
// CONTACT / SUPPORT ROUTES
// ====================================================

app.post('/api/contact', [
  body('name').trim().isLength({ min: 2 }),
  body('email').isEmail().normalizeEmail(),
  body('message').trim().isLength({ min: 10 }),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { name, email, phone, message, source } = req.body;

  try {
    const contact = new Contact({ name, email, phone, message, source });
    await contact.save();

    // Send notification email
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });

    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: process.env.ADMIN_EMAIL || 'admin@kahf.ai',
      subject: `New Contact Form - ${name}`,
      html: `
        <h2>New Contact Form Submission</h2>
        <p><strong>Name:</strong> ${name}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Phone:</strong> ${phone || 'N/A'}</p>
        <p><strong>Source:</strong> ${source || 'website'}</p>
        <p><strong>Message:</strong></p>
        <p>${message}</p>
      `,
    });

    res.json({ message: 'Message sent successfully' });
  } catch (error) {
    console.error('Contact error:', error);
    res.status(500).json({ message: 'Failed to send message' });
  }
});

app.get('/api/admin/contacts', authMiddleware, authorize('admin'), async (req, res) => {
  try {
    const contacts = await Contact.find().sort({ createdAt: -1 }).limit(100);
    res.json({ contacts });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch contacts' });
  }
});

// ====================================================
// HEALTH CHECK
// ====================================================

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// ====================================================
// ERROR HANDLING
// ====================================================

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Something went wrong!' });
});

// ====================================================
// START SERVER
// ====================================================

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 كهف AI Pro Server running on port ${PORT}`);
  console.log(`📧 Contact: admin@kahf.ai | 📱 WhatsApp: +966XXXXXXXXX`);
});

module.exports = app;
