import React, { createContext, useContext, useEffect, useState } from 'react'
import { loadStripe } from '@stripe/stripe-js'

const STRIPE_PUBLIC_KEY = import.meta.env.VITE_STRIPE_PUBLIC_KEY || 'pk_test_your_key'

const StripeContext = createContext(null)

export function StripeProvider({ children }) {
  const [stripe, setStripe] = useState(null)

  useEffect(() => {
    loadStripe(STRIPE_PUBLIC_KEY).then(setStripe)
  }, [])

  return (
    <StripeContext.Provider value={{ stripe }}>
      {children}
    </StripeContext.Provider>
  )
}

export const useStripe = () => {
  const context = useContext(StripeContext)
  if (!context) throw new Error('useStripe must be used within StripeProvider')
  return context
}
