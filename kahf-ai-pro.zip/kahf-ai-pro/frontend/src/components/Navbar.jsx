import React, { useState, useEffect } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import { Menu, X, User, LogOut, Shield, History, CreditCard, ChevronDown } from 'lucide-react'

export default function Navbar() {
  const { user, isAuthenticated, logout } = useAuth()
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [dropdownOpen, setDropdownOpen] = useState(false)
  const location = useLocation()
  const navigate = useNavigate()

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    setMobileOpen(false)
    setDropdownOpen(false)
  }, [location])

  const handleLogout = async () => {
    await logout()
    navigate('/')
  }

  const navLinks = [
    { to: '/', label: 'الرئيسية' },
    { to: '/pricing', label: 'الأسعار' },
    { to: '/contact', label: 'تواصل معنا' },
  ]

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 h-16 transition-all duration-300 ${scrolled ? 'glass-effect' : ''}`}>
      <div className="max-w-7xl mx-auto px-4 h-full flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 no-underline">
          <svg width="30" height="30" viewBox="0 0 32 32" fill="none">
            <path d="M16 2C10 2 6 8 6 14c0 4 2 8 4 10v4c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2v-4c2-2 4-6 4-10 0-6-4-12-10-12zm-4 28v-2h8v2h-8z" fill="#b4befe" opacity="0.9"/>
            <ellipse cx="16" cy="14" rx="4" ry="6" fill="#1e1e2e"/>
            <circle cx="13" cy="12" r="1" fill="#b4befe" opacity="0.5"/>
            <circle cx="19" cy="12" r="1" fill="#b4befe" opacity="0.5"/>
          </svg>
          <span className="text-white font-extrabold text-lg">كهف</span>
          <span className="text-overlay1 text-sm">AI</span>
          {user?.plan === 'pro' && <span className="text-xs bg-lavender text-base px-2 py-0.5 rounded-full font-bold">PRO</span>}
          {user?.plan === 'business' && <span className="text-xs bg-mauve text-base px-2 py-0.5 rounded-full font-bold">BUSINESS</span>}
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map(link => (
            <Link key={link.to} to={link.to} className="text-subtext hover:text-lavender transition-colors text-sm no-underline">
              {link.label}
            </Link>
          ))}
        </div>

        {/* Auth Buttons */}
        <div className="hidden md:flex items-center gap-3">
          {isAuthenticated && user ? (
            <div className="relative">
              <button 
                onClick={() => setDropdownOpen(!dropdownOpen)}
                className="flex items-center gap-2 px-3 py-2 bg-surface0 border border-surface1 rounded-lg hover:border-lavender transition-all"
              >
                <div className="w-7 h-7 bg-gradient-to-br from-lavender to-mauve rounded-full flex items-center justify-center text-xs font-bold text-base">
                  {user.name.charAt(0)}
                </div>
                <span className="text-sm">{user.name}</span>
                <ChevronDown size={14} className={`transition-transform ${dropdownOpen ? 'rotate-180' : ''}`} />
              </button>

              {dropdownOpen && (
                <div className="absolute top-full left-0 mt-2 w-56 bg-mantle border border-surface0 rounded-xl shadow-2xl overflow-hidden">
                  {user.role === 'admin' && (
                    <>
                      <Link to="/admin" className="flex items-center gap-2 px-4 py-3 text-mauve hover:bg-surface0 transition-colors no-underline">
                        <Shield size={16} /> لوحة التحكم
                      </Link>
                      <div className="h-px bg-surface0" />
                    </>
                  )}
                  <Link to="/dashboard" className="flex items-center gap-2 px-4 py-3 text-subtext hover:bg-surface0 transition-colors no-underline">
                    <User size={16} /> لوحة المستخدم
                  </Link>
                  <Link to="/history" className="flex items-center gap-2 px-4 py-3 text-subtext hover:bg-surface0 transition-colors no-underline">
                    <History size={16} /> سجل الترجمات
                  </Link>
                  <Link to="/pricing" className="flex items-center gap-2 px-4 py-3 text-subtext hover:bg-surface0 transition-colors no-underline">
                    <CreditCard size={16} /> الاشتراك
                  </Link>
                  <div className="h-px bg-surface0" />
                  <button onClick={handleLogout} className="flex items-center gap-2 px-4 py-3 text-red hover:bg-surface0 transition-colors w-full text-right">
                    <LogOut size={16} /> تسجيل الخروج
                  </button>
                </div>
              )}
            </div>
          ) : (
            <>
              <Link to="/?auth=login" className="btn-outline text-sm no-underline">تسجيل الدخول</Link>
              <Link to="/?auth=register" className="btn-primary text-sm no-underline">حساب جديد</Link>
            </>
          )}
        </div>

        {/* Mobile Toggle */}
        <button 
          className="md:hidden text-subtext hover:text-lavender transition-colors"
          onClick={() => setMobileOpen(!mobileOpen)}
        >
          {mobileOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="md:hidden bg-mantle border-t border-surface0 p-4 space-y-3">
          {navLinks.map(link => (
            <Link key={link.to} to={link.to} className="block text-subtext hover:text-lavender py-2 no-underline">
              {link.label}
            </Link>
          ))}
          {isAuthenticated && user && (
            <>
              <Link to="/dashboard" className="block text-subtext hover:text-lavender py-2 no-underline">لوحة المستخدم</Link>
              <Link to="/history" className="block text-subtext hover:text-lavender py-2 no-underline">سجل الترجمات</Link>
              {user.role === 'admin' && (
                <Link to="/admin" className="block text-mauve py-2 no-underline">لوحة التحكم</Link>
              )}
              <button onClick={handleLogout} className="block text-red py-2 w-full text-right">تسجيل الخروج</button>
            </>
          )}
          {!isAuthenticated && (
            <div className="flex gap-3 pt-2">
              <Link to="/?auth=login" className="btn-outline flex-1 text-center no-underline">دخول</Link>
              <Link to="/?auth=register" className="btn-primary flex-1 text-center no-underline">تسجيل</Link>
            </div>
          )}
        </div>
      )}
    </nav>
  )
}
